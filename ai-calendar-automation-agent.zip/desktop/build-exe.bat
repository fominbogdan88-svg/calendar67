@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo Sborka Raspisanie.exe (nuzhen internet, 3-5 minut)...
call npm install
if errorlevel 1 ( echo [!] Oshibka npm install & pause & exit /b 1 )
call npm run build
if errorlevel 1 ( echo [!] Oshibka sborki & pause & exit /b 1 )
echo.
echo Gotovo! Fajl: %~dp0dist\Raspisanie.exe
start "" "%~dp0dist"
pause
