// Оболочка «Расписание онлайн-уроков»: запускает сервер приложения и показывает его в отдельном окне.
// .exe можно положить куда угодно: при первом запуске он спросит папку с приложением и запомнит её.
const { app, BrowserWindow, Menu, Tray, dialog, nativeImage, shell } = require("electron");
const { spawn, spawnSync } = require("child_process");
const fs = require("fs");
const http = require("http");
const path = require("path");

const PORT = Number(process.env.PORT || 3000);
const URL_ = `http://localhost:${PORT}`;
const cfgFile = () => path.join(app.getPath("userData"), "config.json");

let win = null;
let splash = null;
let tray = null;
let server = null;
let quitting = false;

function readCfg() {
  try {
    return JSON.parse(fs.readFileSync(cfgFile(), "utf8"));
  } catch {
    return {};
  }
}
function writeCfg(c) {
  fs.mkdirSync(path.dirname(cfgFile()), { recursive: true });
  fs.writeFileSync(cfgFile(), JSON.stringify(c));
}

function isAppDir(dir) {
  try {
    const pkg = JSON.parse(fs.readFileSync(path.join(dir, "package.json"), "utf8"));
    return pkg.name === "nextjs-postgresql-template" && fs.existsSync(path.join(dir, "src"));
  } catch {
    return false;
  }
}

function findAppDir() {
  const cands = [
    process.env.SCHEDULE_APP_DIR,
    readCfg().appDir,
    process.env.PORTABLE_EXECUTABLE_DIR,
    process.env.PORTABLE_EXECUTABLE_DIR && path.join(process.env.PORTABLE_EXECUTABLE_DIR, ".."),
    path.join(__dirname, ".."),
    path.dirname(process.execPath),
    path.join(path.dirname(process.execPath), ".."),
  ].filter(Boolean);
  for (const c of cands) if (isAppDir(c)) return c;
  const r = dialog.showOpenDialogSync({
    title: "Выберите папку с приложением «Расписание» (где лежит start-app.bat)",
    properties: ["openDirectory"],
  });
  if (r && r[0] && isAppDir(r[0])) {
    writeCfg({ ...readCfg(), appDir: r[0] });
    return r[0];
  }
  return null;
}

function ping() {
  return new Promise((resolve) => {
    const req = http.get(`${URL_}/api/health`, (res) => {
      res.resume();
      resolve(res.statusCode === 200);
    });
    req.on("error", () => resolve(false));
    req.setTimeout(1500, () => {
      req.destroy();
      resolve(false);
    });
  });
}

function setSplash(text) {
  if (!splash) return;
  const html = `<body style="margin:0;background:#000;color:#f5f6f7;font-family:Segoe UI,sans-serif;display:flex;align-items:center;justify-content:center;height:100vh;flex-direction:column">
  <div style="font-size:20px;font-weight:700;color:#00e599">РАСПИСАНИЕ</div><div style="margin-top:14px;color:#a3a7ab;font-size:14px;text-align:center;padding:0 24px">${text}</div></body>`;
  splash.loadURL("data:text/html;charset=utf-8," + encodeURIComponent(html));
}

function run(cmd, cwd) {
  return new Promise((resolve) => {
    const p = spawn(cmd, { cwd, shell: true, windowsHide: true, stdio: "ignore" });
    p.on("exit", (code) => resolve(code === 0));
  });
}

async function startServer(dir) {
  if (await ping()) return true; // уже запущен (например, через start-app.bat)
  if (!fs.existsSync(path.join(dir, "node_modules"))) {
    setSplash("Первая настройка: установка компонентов (5–10 минут)…");
    if (!(await run("npm install", dir))) return false;
  }
  if (!fs.existsSync(path.join(dir, ".next", "BUILD_ID"))) {
    setSplash("Первая настройка: сборка приложения…");
    if (!(await run("npm run build", dir))) return false;
  }
  setSplash("Проверка базы данных…");
  await run("npx drizzle-kit push --force", dir);
  setSplash("Запуск…");
  server = spawn("npm run start", { cwd: dir, shell: true, windowsHide: true, stdio: "ignore", env: { ...process.env, PORT: String(PORT) } });
  for (let i = 0; i < 90; i++) {
    if (await ping()) return true;
    await new Promise((r) => setTimeout(r, 1000));
  }
  return false;
}

function stopServer() {
  if (!server) return;
  try {
    if (process.platform === "win32") spawnSync("taskkill", ["/pid", String(server.pid), "/T", "/F"]);
    else server.kill();
  } catch {
    // ignore
  }
  server = null;
}

function createWindow() {
  win = new BrowserWindow({
    width: 1360,
    height: 880,
    minWidth: 900,
    minHeight: 600,
    backgroundColor: "#000000",
    title: "Расписание онлайн-уроков",
    icon: path.join(__dirname, "icon.png"),
    autoHideMenuBar: true,
    webPreferences: { contextIsolation: true },
  });
  Menu.setApplicationMenu(null);
  win.loadURL(URL_);
  win.webContents.setWindowOpenHandler(({ url }) => {
    if (!url.startsWith(URL_)) {
      shell.openExternal(url);
      return { action: "deny" };
    }
    return { action: "allow" };
  });
  // Закрытие окна сворачивает в трей — напоминания продолжают работать.
  win.on("close", (e) => {
    if (!quitting) {
      e.preventDefault();
      win.hide();
    }
  });
}

function createTray() {
  const img = nativeImage.createFromPath(path.join(__dirname, "icon.png")).resize({ width: 16, height: 16 });
  tray = new Tray(img);
  tray.setToolTip("Расписание онлайн-уроков");
  tray.setContextMenu(
    Menu.buildFromTemplate([
      { label: "Открыть", click: () => win && (win.show(), win.focus()) },
      {
        label: "Выход (напоминания остановятся)",
        click: () => {
          quitting = true;
          app.quit();
        },
      },
    ]),
  );
  tray.on("click", () => win && (win.show(), win.focus()));
}

if (!app.requestSingleInstanceLock()) app.quit();
else {
  app.on("second-instance", () => win && (win.show(), win.focus()));
  app.whenReady().then(async () => {
    splash = new BrowserWindow({ width: 440, height: 240, frame: false, resizable: false, backgroundColor: "#000000", alwaysOnTop: true });
    setSplash("Поиск приложения…");
    const dir = findAppDir();
    if (!dir) {
      dialog.showErrorBox("Не найдена папка приложения", "Укажите папку, где лежит start-app.bat. Запустите Raspisanie.exe ещё раз.");
      return app.quit();
    }
    const ok = await startServer(dir);
    splash.close();
    splash = null;
    if (!ok) {
      dialog.showErrorBox("Не удалось запустить", "Проверьте, что установлены Node.js и PostgreSQL, и один раз запустите start-app.bat — он покажет, в чём проблема.");
      stopServer();
      return app.quit();
    }
    createWindow();
    createTray();
  });
  app.on("before-quit", () => {
    quitting = true;
    stopServer();
  });
  app.on("window-all-closed", () => {});
}
