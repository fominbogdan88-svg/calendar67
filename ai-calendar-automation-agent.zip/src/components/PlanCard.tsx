"use client";

import { useState } from "react";
import { api } from "@/lib/client";
import type { NormOp } from "@/lib/types";
import { Badge, Button, Icon, useToast } from "./ui";

export type PlanData = {
  id: number;
  kind: string;
  status: string;
  title: string;
  ops: NormOp[];
  result: string;
};

const ICON: Record<string, { icon: string; cls: string }> = {
  add: { icon: "plus", cls: "text-link" },
  update: { icon: "edit", cls: "text-warn" },
  cancel: { icon: "trash", cls: "text-danger" },
  restore: { icon: "undo", cls: "text-link" },
};

export default function PlanCard({ plan, onDone }: { plan: PlanData; onDone?: () => void }) {
  const toast = useToast();
  const [busy, setBusy] = useState<"apply" | "reject" | null>(null);
  const hasCancel = plan.ops.some((o) => o.op === "cancel");

  async function act(action: "apply" | "reject") {
    setBusy(action);
    try {
      const r = await api<{ message?: string }>(`/api/plans/${plan.id}`, { body: { action } });
      toast(action === "apply" ? `Готово: ${r.message}` : "План отклонён", action === "apply" ? "ok" : "info");
    } catch (e) {
      toast((e as Error).message, "error");
    } finally {
      setBusy(null);
      onDone?.();
    }
  }

  return (
    <div className="mt-3 rounded-lg border border-line bg-bg p-4">
      <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-2 text-sm font-semibold">
          <Icon name="shield" size={16} className="text-link" />
          План изменений #{plan.id}
          {plan.kind === "sync" && <Badge>сайт: {plan.title}</Badge>}
        </div>
        {plan.status === "pending" ? (
          <Badge tone="warn">ждёт вашего подтверждения</Badge>
        ) : plan.status === "applied" ? (
          <Badge tone="ok">выполнен</Badge>
        ) : plan.status === "rejected" ? (
          <Badge>отклонён</Badge>
        ) : (
          <Badge tone="danger">ошибка</Badge>
        )}
      </div>
      <ul className="space-y-2">
        {plan.ops.map((o, i) => (
          <li key={i} className="flex gap-2 text-sm">
            <Icon name={ICON[o.op]?.icon ?? "check"} size={16} className={`mt-0.5 ${ICON[o.op]?.cls ?? ""}`} />
            <div className="min-w-0">
              <div className={o.op === "cancel" ? "text-danger" : ""}>{o.label}</div>
              {o.warnings.map((w, j) => (
                <div key={j} className="flex items-center gap-1 text-xs text-warn">
                  <Icon name="alert" size={12} /> {w}
                </div>
              ))}
            </div>
          </li>
        ))}
      </ul>
      {plan.status === "pending" && (
        <div className="mt-4 flex flex-wrap items-center gap-2">
          <Button variant="primary" icon="check" loading={busy === "apply"} disabled={!!busy} onClick={() => act("apply")}>
            Подтвердить
          </Button>
          <Button variant="secondary" icon="x" loading={busy === "reject"} disabled={!!busy} onClick={() => act("reject")}>
            Отклонить
          </Button>
          {hasCancel && <span className="text-xs text-muted">В плане есть отмены — они выполняются только с вашего согласия.</span>}
        </div>
      )}
      {plan.status !== "pending" && plan.result && <p className="mt-3 text-xs text-muted">{plan.result}</p>}
    </div>
  );
}
