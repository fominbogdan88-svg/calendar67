"use client";

import { useCallback, useEffect, useState } from "react";
import { api } from "@/lib/client";
import PlanCard, { type PlanData } from "./PlanCard";

export default function PendingPlans({ onChange }: { onChange?: () => void }) {
  const [plans, setPlans] = useState<PlanData[]>([]);
  const load = useCallback(() => {
    api<{ plans: PlanData[] }>("/api/plans")
      .then((r) => setPlans(r.plans))
      .catch(() => undefined);
  }, []);
  useEffect(() => {
    load();
    const id = setInterval(load, 20000);
    return () => clearInterval(id);
  }, [load]);
  if (!plans.length) return null;
  return (
    <div className="mb-6 rounded-lg border border-accent/40 bg-accent/5 p-4">
      <div className="text-sm font-semibold">Ожидают вашего решения: {plans.length}</div>
      <p className="mt-1 text-xs text-muted">Агент ничего не меняет в календаре без подтверждения (кроме включённого автоприменения безопасных правок).</p>
      {plans.map((p) => (
        <PlanCard
          key={p.id}
          plan={p}
          onDone={() => {
            load();
            onChange?.();
          }}
        />
      ))}
    </div>
  );
}
