"use client";

import { useEffect, useState } from "react";

export default function OriginCode({ path = "" }: { path?: string }) {
  const [o, setO] = useState("http://localhost:3000");
  useEffect(() => setO(window.location.origin), []);
  return <code>{o + path}</code>;
}
