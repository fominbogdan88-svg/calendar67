"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useCallback, useEffect, useState, type ReactNode } from "react";
import { api } from "@/lib/client";
import { ACCENTS, applyAccent, applyTheme, loadTheme, saveTheme, type ThemeMode } from "@/lib/theme";
import { Icon, ToastProvider } from "./ui";

const NAV = [
  { href: "/", label: "Календарь", icon: "calendar" },
  { href: "/chat", label: "Чат с агентом", icon: "chat" },
  { href: "/sources", label: "Источники (сайты)", icon: "globe" },
  { href: "/history", label: "История и откат", icon: "history" },
  { href: "/settings", label: "Настройки", icon: "settings" },
  { href: "/guide", label: "Инструкция", icon: "book" },
];

type Status = { pendingPlans: number; google: boolean; telegram: boolean; provider: string };

export default function AppShell({ children }: { children: ReactNode }) {
  const path = usePathname();
  const [collapsed, setCollapsed] = useState(false);
  const [mobile, setMobile] = useState(false);
  const [mode, setMode] = useState<ThemeMode>("dark");
  const [accent, setAccent] = useState(ACCENTS[0]);
  const [palette, setPalette] = useState(false);
  const [status, setStatus] = useState<Status | null>(null);

  useEffect(() => {
    const t = loadTheme();
    setMode(t.mode);
    setAccent(t.accent);
    setCollapsed(localStorage.getItem("collapsed") === "1");
  }, []);

  const refresh = useCallback(() => {
    api<Status>("/api/status").then(setStatus).catch(() => undefined);
  }, []);
  useEffect(() => {
    refresh();
    const id = setInterval(refresh, 30000);
    return () => clearInterval(id);
  }, [refresh, path]);

  useEffect(() => setMobile(false), [path]);

  function pickMode(m: ThemeMode) {
    setMode(m);
    applyTheme(m);
    saveTheme(m, accent);
  }
  function pickAccent(a: string) {
    setAccent(a);
    applyAccent(a);
    saveTheme(mode, a);
  }

  const providerName = status?.provider === "ollama" ? "Ollama" : status?.provider === "openai" ? "API" : status?.provider === "manual" ? "Веб-чат" : "…";

  const sidebar = (
    <nav className="flex h-full flex-col px-3 pb-3 pt-4">
      {!collapsed && <div className="px-2 pb-2 text-[11px] font-semibold tracking-wider text-muted">ПРИЛОЖЕНИЕ</div>}
      <ul className="space-y-1">
        {NAV.map((n) => {
          const active = n.href === "/" ? path === "/" : path.startsWith(n.href);
          return (
            <li key={n.href}>
              <Link
                href={n.href}
                title={n.label}
                className={`flex h-10 items-center gap-3 rounded-md px-2.5 text-sm transition ${active ? "bg-panel2 font-semibold text-fg" : "text-muted hover:bg-panel2/60 hover:text-fg"} ${collapsed ? "justify-center" : ""}`}
              >
                <Icon name={n.icon} className={active ? "text-link" : ""} />
                {!collapsed && <span className="truncate">{n.label}</span>}
                {!collapsed && n.href === "/" && !!status?.pendingPlans && (
                  <span className="ml-auto rounded-full bg-accent px-1.5 text-[11px] font-bold text-accent-fg">{status.pendingPlans}</span>
                )}
              </Link>
            </li>
          );
        })}
      </ul>
      <div className="mt-auto space-y-1 border-t border-line pt-3">
        <button
          onClick={() => {
            setCollapsed(!collapsed);
            localStorage.setItem("collapsed", collapsed ? "0" : "1");
          }}
          className={`hidden h-10 w-full cursor-pointer items-center gap-3 rounded-md px-2.5 text-sm text-muted hover:bg-panel2/60 hover:text-fg md:flex ${collapsed ? "justify-center" : ""}`}
        >
          <Icon name="panel" />
          {!collapsed && "Свернуть меню"}
        </button>
      </div>
    </nav>
  );

  return (
    <ToastProvider>
      <div className="flex h-screen flex-col bg-sidebar">
        <header className="relative z-30 flex h-14 shrink-0 items-center gap-3 px-4">
          <button className="cursor-pointer rounded p-1.5 text-muted hover:bg-panel2 md:hidden" onClick={() => setMobile(!mobile)} aria-label="Меню">
            <Icon name="menu" />
          </button>
          <Link href="/" className="flex items-center gap-2 font-bold tracking-tight">
            <span className="flex h-7 w-7 items-center justify-center rounded-md bg-accent text-accent-fg">
              <Icon name="calendar" size={16} />
            </span>
            <span className="hidden sm:inline">РАСПИСАНИЕ</span>
          </Link>
          <div className="mx-auto hidden items-center gap-2 lg:flex">
            <Link href="/settings#ai" className="flex h-8 items-center gap-2 rounded-md border border-line px-3 text-xs text-muted hover:bg-panel2 hover:text-fg">
              <Icon name="sparkles" size={14} className="text-link" /> ИИ: {providerName}
            </Link>
            <Link href="/settings#google" className="flex h-8 items-center gap-2 rounded-md border border-line px-3 text-xs text-muted hover:bg-panel2 hover:text-fg">
              <span className={`h-2 w-2 rounded-full ${status?.google ? "bg-accent" : "bg-warn"}`} /> Google {status?.google ? "подключён" : "не подключён"}
            </Link>
            <Link href="/settings#telegram" className="flex h-8 items-center gap-2 rounded-md border border-line px-3 text-xs text-muted hover:bg-panel2 hover:text-fg">
              <span className={`h-2 w-2 rounded-full ${status?.telegram ? "bg-accent" : "bg-warn"}`} /> Telegram {status?.telegram ? "подключён" : "не подключён"}
            </Link>
          </div>
          <div className="relative ml-auto flex items-center gap-2 lg:ml-0">
            <button
              onClick={() => pickMode(mode === "dark" ? "light" : "dark")}
              className="flex h-9 w-9 cursor-pointer items-center justify-center rounded-md border border-line text-muted hover:bg-panel2 hover:text-fg"
              title={mode === "dark" ? "Включить светлую тему" : "Включить тёмную тему"}
              aria-label="Сменить тему"
            >
              <Icon name={mode === "dark" ? "sun" : "moon"} />
            </button>
            <button
              onClick={() => setPalette(!palette)}
              className="flex h-9 cursor-pointer items-center gap-2 rounded-md border border-line px-3 text-sm text-muted hover:bg-panel2 hover:text-fg"
              aria-label="Цвет оформления"
            >
              <span className="h-4 w-4 rounded-full border border-line" style={{ background: accent }} />
              <span className="hidden sm:inline">Цвет</span>
            </button>
            {palette && (
              <>
                <div className="fixed inset-0 z-40" onClick={() => setPalette(false)} />
                <div className="pop absolute right-0 top-11 z-50 w-72 rounded-lg border border-line bg-panel p-4 shadow-2xl">
                  <div className="mb-2 text-sm font-semibold">Основной цвет</div>
                  <div className="grid grid-cols-8 gap-2">
                    {ACCENTS.map((c) => (
                      <button
                        key={c}
                        onClick={() => pickAccent(c)}
                        className={`h-7 w-7 cursor-pointer rounded-full border-2 ${accent.toLowerCase() === c ? "border-fg" : "border-transparent"}`}
                        style={{ background: c }}
                        aria-label={c}
                      />
                    ))}
                  </div>
                  <label className="mt-3 flex items-center justify-between gap-3 text-sm text-muted">
                    Свой цвет
                    <input type="color" value={accent} onChange={(e) => pickAccent(e.target.value)} className="h-8 w-14 cursor-pointer rounded border border-line bg-transparent" />
                  </label>
                  <div className="mb-2 mt-4 text-sm font-semibold">Тема</div>
                  <div className="grid grid-cols-3 gap-2">
                    {(["dark", "light", "system"] as ThemeMode[]).map((m) => (
                      <button
                        key={m}
                        onClick={() => pickMode(m)}
                        className={`h-8 cursor-pointer rounded-md border text-xs ${mode === m ? "border-accent bg-accent/10 text-fg" : "border-line text-muted hover:bg-panel2"}`}
                      >
                        {m === "dark" ? "Тёмная" : m === "light" ? "Светлая" : "Как в ОС"}
                      </button>
                    ))}
                  </div>
                </div>
              </>
            )}
          </div>
        </header>
        <div className="relative flex min-h-0 flex-1">
          <aside className={`hidden shrink-0 transition-all md:block ${collapsed ? "w-[68px]" : "w-64"}`}>{sidebar}</aside>
          {mobile && (
            <div className="fixed inset-0 top-14 z-20 md:hidden" onClick={() => setMobile(false)}>
              <aside className="h-full w-64 border-r border-line bg-sidebar" onClick={(e) => e.stopPropagation()}>
                {sidebar}
              </aside>
            </div>
          )}
          <main className="min-w-0 flex-1 overflow-y-auto rounded-tl-xl border-l border-t border-line bg-bg">{children}</main>
        </div>
      </div>
    </ToastProvider>
  );
}
