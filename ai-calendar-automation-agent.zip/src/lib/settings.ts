import { db } from "@/db";
import { settings } from "@/db/schema";
import { decrypt, encrypt } from "./crypto";
import { detectTz } from "./time";

export const MASK = "••••••••";

export const SECRET_KEYS = new Set(["openaiKey", "googleClientSecret", "googleRefreshToken", "tgToken"]);

export const DEFAULTS: Record<string, string> = {
  timezone: detectTz(),
  // ИИ
  aiProvider: "ollama", // ollama | openai | manual
  ollamaUrl: "http://127.0.0.1:11434",
  ollamaModel: "qwen3:8b",
  ollamaVisionModel: "",
  openaiBaseUrl: "https://api.openai.com/v1",
  openaiModel: "gpt-4o-mini",
  openaiKey: "",
  // Google
  googleClientId: "",
  googleClientSecret: "",
  googleRefreshToken: "",
  googleCalendarId: "",
  googleRedirectOrigin: "",
  googlePush: "true",
  // Telegram
  tgToken: "",
  tgChatId: "",
  tgBindCode: "",
  tgUpdateOffset: "0",
  tgReminders: "true",
  tgReminderMinutes: "30",
  tgDigest: "true",
  tgDigestTime: "08:00",
  tgReports: "true",
  // Автоматизация
  backgroundEnabled: "true",
  autoApplyChat: "false",
  defaultDuration: "60",
  browserChannel: "msedge",
};

export type Settings = Record<string, string>;

export async function getSettings(): Promise<Settings> {
  const rows = await db.select().from(settings);
  const out: Settings = { ...DEFAULTS };
  for (const r of rows) out[r.key] = SECRET_KEYS.has(r.key) ? decrypt(r.value) : r.value;
  return out;
}

export async function saveSettings(patch: Record<string, string>): Promise<void> {
  for (const [k, raw] of Object.entries(patch)) {
    if (!(k in DEFAULTS)) continue;
    const v = String(raw ?? "");
    const secret = SECRET_KEYS.has(k);
    if (secret && v === MASK) continue;
    const stored = secret && v ? encrypt(v) : v;
    await db
      .insert(settings)
      .values({ key: k, value: stored })
      .onConflictDoUpdate({ target: settings.key, set: { value: stored } });
  }
}

export function publicSettings(s: Settings): Settings {
  const out: Settings = { ...s };
  for (const k of SECRET_KEYS) out[k] = s[k] ? MASK : "";
  return out;
}
