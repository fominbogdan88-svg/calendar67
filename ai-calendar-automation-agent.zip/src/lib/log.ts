import { db } from "@/db";
import { appLogs } from "@/db/schema";

export class UserError extends Error {}

export async function logEvent(level: "info" | "warn" | "error", message: string): Promise<void> {
  const msg = message.slice(0, 2000);
  if (level === "error") console.error("[app]", msg);
  else console.log("[app]", msg);
  try {
    await db.insert(appLogs).values({ level, message: msg });
  } catch {
    // БД может быть ещё не готова — не мешаем работе.
  }
}

export function errMsg(e: unknown): string {
  if (e instanceof Error) return e.message;
  return String(e);
}

export const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));
