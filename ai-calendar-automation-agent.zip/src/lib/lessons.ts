import { and, desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { actionLog, lessons } from "@/db/schema";
import { sha1 } from "./crypto";
import { localToUtc, toLocalParts } from "./time";
import type { Lesson, LessonView, NormOp } from "./types";

export function lessonHash(l: Lesson): string {
  return sha1([l.status, l.title, l.startsAt.toISOString(), l.endsAt.toISOString(), l.link, l.notes].join("|"));
}

export function toView(l: Lesson, tz: string): LessonView {
  const s = toLocalParts(l.startsAt, tz);
  const e = toLocalParts(l.endsAt, tz);
  return {
    id: l.id,
    title: l.title,
    date: s.date,
    start: s.time,
    end: e.time,
    endDate: e.date,
    status: l.status,
    link: l.link,
    notes: l.notes,
    origin: l.origin,
    sourceId: l.sourceId,
    synced: l.googleSyncedHash === lessonHash(l),
  };
}

export type ApplyResult = {
  added: number;
  updated: number;
  cancelled: number;
  restored: number;
  notes: string[];
};

export function summarizeResult(r: ApplyResult): string {
  const parts: string[] = [];
  if (r.added) parts.push(`добавлено: ${r.added}`);
  if (r.updated) parts.push(`изменено: ${r.updated}`);
  if (r.cancelled) parts.push(`отменено: ${r.cancelled}`);
  if (r.restored) parts.push(`восстановлено: ${r.restored}`);
  const base = parts.length ? parts.join(", ") : "изменений нет";
  return r.notes.length ? `${base}. ${r.notes.join("; ")}` : base;
}

/** Применяет одобренные операции к локальному расписанию и пишет журнал (для отката). */
export async function applyOps(
  ops: NormOp[],
  o: { planId?: number | null; batchId: string; sourceId?: number | null; origin: string; tz: string },
): Promise<ApplyResult> {
  const res: ApplyResult = { added: 0, updated: 0, cancelled: 0, restored: 0, notes: [] };
  await db.transaction(async (tx) => {
    for (const op of ops) {
      if (op.op === "add") {
        const [row] = await tx
          .insert(lessons)
          .values({
            sourceId: o.sourceId ?? null,
            title: op.title!,
            startsAt: localToUtc(op.start!, o.tz),
            endsAt: localToUtc(op.end!, o.tz),
            link: op.link ?? "",
            notes: op.notes ?? "",
            origin: o.origin,
          })
          .returning();
        await tx.insert(actionLog).values({
          batchId: o.batchId,
          planId: o.planId ?? null,
          lessonId: row.id,
          op: "add",
          summary: op.label,
          before: null,
          after: row,
        });
        res.added++;
        continue;
      }
      const [before] = await tx.select().from(lessons).where(eq(lessons.id, op.lessonId!));
      if (!before || before.status === "deleted") {
        res.notes.push(`урок #${op.lessonId} не найден — пропущено`);
        continue;
      }
      let patch: Partial<Lesson> = {};
      if (op.op === "update") {
        patch = {
          title: op.title!,
          startsAt: localToUtc(op.start!, o.tz),
          endsAt: localToUtc(op.end!, o.tz),
          link: op.link ?? before.link,
          notes: op.notes ?? before.notes,
        };
      } else if (op.op === "cancel") patch = { status: "cancelled" };
      else if (op.op === "restore") patch = { status: "active" };
      const [after] = await tx
        .update(lessons)
        .set({ ...patch, updatedAt: new Date() })
        .where(eq(lessons.id, before.id))
        .returning();
      await tx.insert(actionLog).values({
        batchId: o.batchId,
        planId: o.planId ?? null,
        lessonId: before.id,
        op: op.op,
        summary: op.label,
        before,
        after,
      });
      if (op.op === "update") res.updated++;
      else if (op.op === "cancel") res.cancelled++;
      else res.restored++;
    }
  });
  return res;
}

/** Откат целой пачки изменений. */
export async function undoBatch(batchId: string): Promise<number> {
  const rows = await db
    .select()
    .from(actionLog)
    .where(and(eq(actionLog.batchId, batchId), eq(actionLog.undone, false)))
    .orderBy(desc(actionLog.id));
  let n = 0;
  await db.transaction(async (tx) => {
    for (const r of rows) {
      if (r.op === "add") {
        await tx.update(lessons).set({ status: "deleted", updatedAt: new Date() }).where(eq(lessons.id, r.lessonId));
      } else if (r.before) {
        const b = r.before as Record<string, unknown>;
        await tx
          .update(lessons)
          .set({
            title: String(b.title),
            startsAt: new Date(String(b.startsAt)),
            endsAt: new Date(String(b.endsAt)),
            link: String(b.link ?? ""),
            notes: String(b.notes ?? ""),
            status: String(b.status),
            updatedAt: new Date(),
          })
          .where(eq(lessons.id, r.lessonId));
      }
      await tx.update(actionLog).set({ undone: true }).where(eq(actionLog.id, r.id));
      n++;
    }
  });
  return n;
}
