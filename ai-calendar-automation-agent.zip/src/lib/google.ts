import { and, eq, gte, isNotNull, or } from "drizzle-orm";
import { db } from "@/db";
import { lessons } from "@/db/schema";
import { errMsg, logEvent, sleep, UserError } from "./log";
import { lessonHash } from "./lessons";
import { getSettings, saveSettings, type Settings } from "./settings";
import type { Lesson } from "./types";

// Используем узкий доступ: приложение видит и меняет ТОЛЬКО созданный им календарь «Онлайн-уроки».
export const GOOGLE_SCOPE = "https://www.googleapis.com/auth/calendar.app.created";
const API = "https://www.googleapis.com/calendar/v3";
const CAL_NAME = "Онлайн-уроки (ИИ-агент)";

let tokenCache: { token: string; exp: number } | null = null;

export function googleConfigured(s: Settings): boolean {
  return !!(s.googleClientId && s.googleClientSecret);
}
export function googleConnected(s: Settings): boolean {
  return googleConfigured(s) && !!s.googleRefreshToken;
}

export function redirectUri(origin: string): string {
  return `${origin.replace(/\/$/, "")}/api/google/callback`;
}

export function buildAuthUrl(s: Settings, origin: string): string {
  const p = new URLSearchParams({
    client_id: s.googleClientId,
    redirect_uri: redirectUri(origin),
    response_type: "code",
    scope: GOOGLE_SCOPE,
    access_type: "offline",
    prompt: "consent",
  });
  return `https://accounts.google.com/o/oauth2/v2/auth?${p}`;
}

export async function exchangeCode(code: string, origin: string): Promise<void> {
  const s = await getSettings();
  const r = await fetch("https://oauth2.googleapis.com/token", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({
      code,
      client_id: s.googleClientId,
      client_secret: s.googleClientSecret,
      redirect_uri: redirectUri(origin),
      grant_type: "authorization_code",
    }),
  });
  const j = (await r.json()) as { refresh_token?: string; access_token?: string; expires_in?: number; error_description?: string };
  if (!r.ok || !j.refresh_token) {
    throw new UserError(j.error_description || "Google не вернул refresh_token. Отзовите доступ в аккаунте Google и подключитесь заново.");
  }
  await saveSettings({ googleRefreshToken: j.refresh_token });
  tokenCache = j.access_token ? { token: j.access_token, exp: Date.now() + (j.expires_in ?? 3000) * 1000 - 60000 } : null;
}

export async function disconnectGoogle(): Promise<void> {
  await saveSettings({ googleRefreshToken: "", googleCalendarId: "" });
  tokenCache = null;
}

async function accessToken(s: Settings): Promise<string> {
  if (tokenCache && tokenCache.exp > Date.now()) return tokenCache.token;
  const r = await fetch("https://oauth2.googleapis.com/token", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({
      client_id: s.googleClientId,
      client_secret: s.googleClientSecret,
      refresh_token: s.googleRefreshToken,
      grant_type: "refresh_token",
    }),
  });
  const j = (await r.json()) as { access_token?: string; expires_in?: number; error?: string; error_description?: string };
  if (!r.ok || !j.access_token) {
    throw new UserError(
      j.error === "invalid_grant"
        ? "Доступ к Google истёк или отозван. Подключите Google заново в Настройках (если приложение Google в режиме «Testing», доступ живёт всего 7 дней — переведите его в «In production»)."
        : `Google отказал в доступе: ${j.error_description || j.error || r.status}`,
    );
  }
  tokenCache = { token: j.access_token, exp: Date.now() + (j.expires_in ?? 3000) * 1000 - 60000 };
  return j.access_token;
}

async function gfetch(s: Settings, path: string, init: RequestInit = {}, tries = 3): Promise<Response> {
  let last: unknown;
  for (let i = 0; i < tries; i++) {
    try {
      const token = await accessToken(s);
      const r = await fetch(`${API}${path}`, {
        ...init,
        headers: { ...(init.headers || {}), Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
        signal: AbortSignal.timeout(30000),
      });
      if (r.status === 401) tokenCache = null;
      if (r.status === 429 || r.status >= 500 || r.status === 401) {
        last = new Error(`Google API ${r.status}`);
      } else return r;
    } catch (e) {
      if (e instanceof UserError) throw e;
      last = e;
    }
    await sleep(700 * (i + 1));
  }
  throw last instanceof Error ? last : new Error("Нет связи с Google");
}

async function ensureCalendar(s: Settings): Promise<string> {
  if (s.googleCalendarId) return s.googleCalendarId;
  const r = await gfetch(s, "/calendars", {
    method: "POST",
    body: JSON.stringify({ summary: CAL_NAME, description: "Создан приложением «Расписание онлайн-уроков»", timeZone: s.timezone }),
  });
  const j = (await r.json()) as { id?: string; error?: { message?: string } };
  if (!r.ok || !j.id) throw new UserError(`Не удалось создать календарь: ${j.error?.message || r.status}`);
  await saveSettings({ googleCalendarId: j.id });
  s.googleCalendarId = j.id;
  return j.id;
}

function eventBody(l: Lesson, tz: string) {
  const desc = [l.notes, l.link].filter(Boolean).join("\n");
  return {
    summary: l.title,
    description: desc,
    location: /^https?:\/\//.test(l.link) ? l.link : undefined,
    start: { dateTime: l.startsAt.toISOString(), timeZone: tz },
    end: { dateTime: l.endsAt.toISOString(), timeZone: tz },
    extendedProperties: { private: { app: "schedule-agent", lessonId: String(l.id) } },
  };
}

async function findExisting(s: Settings, calId: string, lessonId: number): Promise<string | null> {
  const q = new URLSearchParams({ privateExtendedProperty: `lessonId=${lessonId}`, maxResults: "5" });
  const r = await gfetch(s, `/calendars/${encodeURIComponent(calId)}/events?${q}`);
  if (!r.ok) return null;
  const j = (await r.json()) as { items?: { id: string }[] };
  return j.items?.[0]?.id ?? null;
}

async function markSynced(l: Lesson, eventId: string | null) {
  await db.update(lessons).set({ googleEventId: eventId, googleSyncedHash: lessonHash(l) }).where(eq(lessons.id, l.id));
}

async function syncOne(s: Settings, calId: string, l: Lesson): Promise<void> {
  const base = `/calendars/${encodeURIComponent(calId)}/events`;
  if (l.status !== "active") {
    if (l.googleEventId) {
      const r = await gfetch(s, `${base}/${encodeURIComponent(l.googleEventId)}`, { method: "DELETE" });
      if (!r.ok && r.status !== 404 && r.status !== 410) throw new Error(`удаление события: HTTP ${r.status}`);
    }
    await markSynced(l, null);
    return;
  }
  let eventId = l.googleEventId ?? (await findExisting(s, calId, l.id));
  if (eventId) {
    // Изменяем существующее событие (PATCH), а не удаляем и создаём заново.
    const r = await gfetch(s, `${base}/${encodeURIComponent(eventId)}`, { method: "PATCH", body: JSON.stringify(eventBody(l, s.timezone)) });
    if (r.ok) return void (await markSynced(l, eventId));
    if (r.status !== 404 && r.status !== 410) throw new Error(`изменение события: HTTP ${r.status}`);
    eventId = null;
  }
  const r = await gfetch(s, base, { method: "POST", body: JSON.stringify(eventBody(l, s.timezone)) });
  const j = (await r.json()) as { id?: string; error?: { message?: string } };
  if (!r.ok || !j.id) throw new Error(`создание события: ${j.error?.message || r.status}`);
  await markSynced(l, j.id);
}

export type GoogleSyncResult = { enabled: boolean; ok: number; failed: number; errors: string[] };

/** Отправляет в Google все уроки, у которых локальная версия отличается от синхронизированной. */
export async function syncPendingGoogle(): Promise<GoogleSyncResult> {
  const s = await getSettings();
  const res: GoogleSyncResult = { enabled: false, ok: 0, failed: 0, errors: [] };
  if (!googleConnected(s) || s.googlePush !== "true") return res;
  res.enabled = true;
  const since = new Date(Date.now() - 60 * 86400_000);
  const rows = await db
    .select()
    .from(lessons)
    .where(or(gte(lessons.startsAt, since), and(isNotNull(lessons.googleEventId))));
  const pending = rows.filter((l) => l.googleSyncedHash !== lessonHash(l) && !(l.status === "deleted" && !l.googleEventId && !l.googleSyncedHash));
  if (!pending.length) return res;
  try {
    const calId = await ensureCalendar(s);
    for (const l of pending) {
      try {
        await syncOne(s, calId, l);
        res.ok++;
      } catch (e) {
        res.failed++;
        res.errors.push(`«${l.title}»: ${errMsg(e)}`);
      }
    }
  } catch (e) {
    res.failed = pending.length;
    res.errors.push(errMsg(e));
  }
  if (res.failed) await logEvent("warn", `Google: не синхронизировано ${res.failed}: ${res.errors.slice(0, 3).join("; ")}`);
  return res;
}

export function googleSummary(r: GoogleSyncResult): string {
  if (!r.enabled) return "Google не подключён — расписание сохранено только в приложении.";
  if (r.failed) return `Google: ошибка у ${r.failed} уроков (${r.errors[0]}). Повторю автоматически.`;
  return r.ok ? `Google Calendar обновлён (${r.ok}).` : "Google Calendar уже актуален.";
}
