import { eq } from "drizzle-orm";
import { db } from "@/db";
import { chatMessages, plans } from "@/db/schema";
import { googleSummary, syncPendingGoogle } from "./google";
import { applyOps, summarizeResult } from "./lessons";
import { errMsg, logEvent, UserError } from "./log";
import { getSettings } from "./settings";
import { esc, tgSend } from "./telegram";
import type { NormOp } from "./types";

export async function addMessage(
  role: "user" | "assistant" | "tool",
  content: string,
  extra: { kind?: string; images?: string[]; planId?: number | null } = {},
) {
  const [row] = await db
    .insert(chatMessages)
    .values({ role, content, kind: extra.kind ?? "text", images: extra.images ?? [], planId: extra.planId ?? null })
    .returning();
  return row;
}

export async function createPlan(o: { kind: "chat" | "sync"; sourceId?: number | null; title: string; ops: NormOp[] }) {
  const [row] = await db
    .insert(plans)
    .values({ kind: o.kind, sourceId: o.sourceId ?? null, title: o.title, ops: o.ops })
    .returning();
  return row;
}

export async function applyPlan(id: number): Promise<string> {
  const [plan] = await db.select().from(plans).where(eq(plans.id, id));
  if (!plan) throw new UserError("План не найден");
  if (plan.status !== "pending") throw new UserError("Этот план уже обработан");
  const s = await getSettings();
  const ops = plan.ops as NormOp[];
  try {
    const res = await applyOps(ops, {
      planId: plan.id,
      batchId: `plan-${plan.id}-${Date.now()}`,
      sourceId: plan.sourceId,
      origin: plan.kind === "sync" ? "source" : "chat",
      tz: s.timezone,
    });
    const g = await syncPendingGoogle();
    const text = `${summarizeResult(res)}. ${googleSummary(g)}`;
    await db.update(plans).set({ status: "applied", result: text, resolvedAt: new Date() }).where(eq(plans.id, id));
    await addMessage("tool", `Результат выполнения плана #${id}: ${text}`, { kind: "result", planId: id });
    if (plan.kind === "sync" && s.tgReports === "true") {
      const lines = ops.slice(0, 15).map((o) => `• ${esc(o.label)}`);
      await tgSend(`🗓 <b>Расписание обновлено</b> (${esc(plan.title)})\n${lines.join("\n")}`);
    }
    return text;
  } catch (e) {
    const msg = errMsg(e);
    await db.update(plans).set({ status: "failed", result: msg, resolvedAt: new Date() }).where(eq(plans.id, id));
    await addMessage("tool", `План #${id} НЕ выполнен: ${msg}`, { kind: "result", planId: id });
    await logEvent("error", `План #${id}: ${msg}`);
    throw new UserError(`Не удалось применить план: ${msg}`);
  }
}

export async function rejectPlan(id: number): Promise<void> {
  await db.update(plans).set({ status: "rejected", resolvedAt: new Date() }).where(eq(plans.id, id));
  await addMessage("tool", `Пользователь отклонил план #${id}. Ничего не изменено.`, { kind: "result", planId: id });
}
