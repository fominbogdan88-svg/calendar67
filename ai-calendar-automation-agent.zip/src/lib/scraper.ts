import path from "node:path";
import { dataDir } from "./crypto";
import { errMsg, UserError } from "./log";
import { getSettings } from "./settings";

// Чтение сайтов через настоящий браузер (Playwright) — работает с JavaScript-сайтами (React/Vue/Angular).
// Сессия входа хранится в профиле браузера (.data/browser-profile): пароль приложению не нужен —
// вы входите на сайте школы сами в открывшемся окне.

export type ScrapeResult = {
  text: string;
  title: string;
  finalUrl: string;
  needsLogin: boolean;
  blocked: boolean;
};

let chain: Promise<unknown> = Promise.resolve();
function exclusive<T>(fn: () => Promise<T>): Promise<T> {
  const run = chain.then(fn, fn);
  chain = run.catch(() => undefined);
  return run;
}

async function launch(headless: boolean) {
  const { chromium } = await import("playwright-core");
  const s = await getSettings();
  const dir = path.join(dataDir(), "browser-profile");
  const channels = [...new Set([s.browserChannel, "msedge", "chrome", "chromium"])].filter(Boolean);
  let lastErr: unknown;
  for (const ch of channels) {
    try {
      return await chromium.launchPersistentContext(dir, {
        headless,
        channel: ch === "chromium" ? undefined : ch,
        viewport: { width: 1366, height: 900 },
        locale: "ru-RU",
      });
    } catch (e) {
      lastErr = e;
    }
  }
  throw new UserError(
    `Не удалось запустить браузер. Нужен Microsoft Edge или Google Chrome (на Windows Edge есть всегда). Если их нет — выполните в папке приложения: npx playwright-core install chromium. Детали: ${errMsg(lastErr).slice(0, 200)}`,
  );
}

export function scrapePage(url: string, selector: string): Promise<ScrapeResult> {
  return exclusive(async () => {
    const ctx = await launch(true);
    try {
      const page = await ctx.newPage();
      try {
        await page.goto(url, { waitUntil: "domcontentloaded", timeout: 45000 });
      } catch (e) {
        throw new UserError(`Страница не открылась: ${errMsg(e).slice(0, 200)}`);
      }
      await page.waitForLoadState("networkidle", { timeout: 15000 }).catch(() => undefined);
      await page.waitForTimeout(1500);
      // прокрутка — чтобы подгрузились «ленивые» блоки
      await page
        .evaluate(async () => {
          for (let i = 0; i < 6; i++) {
            window.scrollBy(0, document.body.scrollHeight);
            await new Promise((r) => setTimeout(r, 300));
          }
          window.scrollTo(0, 0);
        })
        .catch(() => undefined);
      let text = "";
      if (selector.trim()) {
        text = await page
          .locator(selector.trim())
          .first()
          .innerText({ timeout: 5000 })
          .catch(() => "");
      }
      if (!text) text = await page.evaluate(() => document.body.innerText).catch(() => "");
      const title = await page.title().catch(() => "");
      const needsLogin = (await page.locator("input[type=password]:visible").count().catch(() => 0)) > 0;
      const blocked = text.length < 3000 && /just a moment|checking your browser|verify you are human|captcha|подтвердите, что вы не робот/i.test(`${title}\n${text}`);
      return { text: text.replace(/\n{3,}/g, "\n\n").trim(), title, finalUrl: page.url(), needsLogin, blocked };
    } finally {
      await ctx.close().catch(() => undefined);
    }
  });
}

/** Открывает видимое окно браузера, где пользователь входит на сайт школы. Окно можно закрыть, когда вход выполнен. */
export function openLoginBrowser(url: string): Promise<void> {
  return new Promise((resolve, reject) => {
    exclusive(async () => {
      let ctx;
      try {
        ctx = await launch(false);
      } catch (e) {
        reject(e);
        return;
      }
      const page = await ctx.newPage();
      await page.goto(url, { timeout: 45000 }).catch(() => undefined);
      resolve();
      await new Promise<void>((r) => ctx.on("close", () => r()));
    }).catch(() => undefined);
  });
}
