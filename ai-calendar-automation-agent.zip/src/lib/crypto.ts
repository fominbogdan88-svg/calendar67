import crypto from "node:crypto";
import fs from "node:fs";
import path from "node:path";

// Секреты (токены, пароли, API-ключи) хранятся в БД только в зашифрованном виде (AES-256-GCM).
// Ключ берётся из переменной APP_SECRET либо создаётся автоматически в папке .data/secret.key.

let keyCache: Buffer | null = null;

export function dataDir(): string {
  const dir = path.resolve(/*turbopackIgnore: true*/ process.env.DATA_DIR || ".data");
  fs.mkdirSync(dir, { recursive: true });
  return dir;
}

function getKey(): Buffer {
  if (keyCache) return keyCache;
  if (process.env.APP_SECRET) {
    keyCache = crypto.createHash("sha256").update(process.env.APP_SECRET).digest();
    return keyCache;
  }
  const file = path.join(dataDir(), "secret.key");
  if (!fs.existsSync(file)) {
    fs.writeFileSync(file, crypto.randomBytes(32).toString("hex"), { mode: 0o600 });
  }
  keyCache = Buffer.from(fs.readFileSync(file, "utf8").trim(), "hex");
  return keyCache;
}

export function encrypt(plain: string): string {
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv("aes-256-gcm", getKey(), iv);
  const enc = Buffer.concat([cipher.update(plain, "utf8"), cipher.final()]);
  const tag = cipher.getAuthTag();
  return "enc:" + Buffer.concat([iv, tag, enc]).toString("base64");
}

export function decrypt(value: string): string {
  if (!value.startsWith("enc:")) return value;
  try {
    const buf = Buffer.from(value.slice(4), "base64");
    const iv = buf.subarray(0, 12);
    const tag = buf.subarray(12, 28);
    const data = buf.subarray(28);
    const decipher = crypto.createDecipheriv("aes-256-gcm", getKey(), iv);
    decipher.setAuthTag(tag);
    return Buffer.concat([decipher.update(data), decipher.final()]).toString("utf8");
  } catch {
    return "";
  }
}

export function randomCode(len = 6): string {
  const alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let out = "";
  const bytes = crypto.randomBytes(len);
  for (let i = 0; i < len; i++) out += alphabet[bytes[i] % alphabet.length];
  return out;
}

export function sha1(s: string): string {
  return crypto.createHash("sha1").update(s).digest("hex");
}
