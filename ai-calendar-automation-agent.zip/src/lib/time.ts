// Работа с часовыми поясами без внешних библиотек.

export function isValidTz(tz: string): boolean {
  try {
    new Intl.DateTimeFormat("en-US", { timeZone: tz });
    return true;
  } catch {
    return false;
  }
}

export function detectTz(): string {
  try {
    return Intl.DateTimeFormat().resolvedOptions().timeZone || "UTC";
  } catch {
    return "UTC";
  }
}

function partsIn(date: Date, tz: string): Record<string, string> {
  const f = new Intl.DateTimeFormat("en-CA", {
    timeZone: tz,
    hourCycle: "h23",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
  });
  const o: Record<string, string> = {};
  for (const p of f.formatToParts(date)) o[p.type] = p.value;
  return o;
}

export function toLocalParts(date: Date, tz: string): { date: string; time: string } {
  const p = partsIn(date, tz);
  return { date: `${p.year}-${p.month}-${p.day}`, time: `${p.hour}:${p.minute}` };
}

export function toLocalString(date: Date, tz: string): string {
  const p = toLocalParts(date, tz);
  return `${p.date}T${p.time}`;
}

const LOCAL_RE = /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})$/;

export function isRealLocal(local: string): boolean {
  const m = LOCAL_RE.exec(local);
  if (!m) return false;
  const [y, mo, d, h, mi] = m.slice(1).map(Number);
  if (h > 23 || mi > 59) return false;
  const t = new Date(Date.UTC(y, mo - 1, d, h, mi));
  return (
    t.getUTCFullYear() === y &&
    t.getUTCMonth() === mo - 1 &&
    t.getUTCDate() === d &&
    t.getUTCHours() === h &&
    t.getUTCMinutes() === mi
  );
}

/** "2026-11-14T15:00" в часовом поясе tz -> момент времени (UTC). */
export function localToUtc(local: string, tz: string): Date {
  const m = LOCAL_RE.exec(local);
  if (!m) throw new Error(`Некорректная дата: ${local}`);
  const [y, mo, d, h, mi] = m.slice(1).map(Number);
  const asUtc = Date.UTC(y, mo - 1, d, h, mi);
  let guess = asUtc;
  for (let i = 0; i < 3; i++) {
    const p = partsIn(new Date(guess), tz);
    const shown = Date.UTC(+p.year, +p.month - 1, +p.day, +p.hour, +p.minute);
    guess += asUtc - shown;
  }
  return new Date(guess);
}

export function todayLocal(tz: string): string {
  return toLocalParts(new Date(), tz).date;
}

export function addDays(dateStr: string, n: number): string {
  const [y, m, d] = dateStr.split("-").map(Number);
  const t = new Date(Date.UTC(y, m - 1, d + n));
  return t.toISOString().slice(0, 10);
}

const WD_FULL = ["воскресенье", "понедельник", "вторник", "среда", "четверг", "пятница", "суббота"];
const WD_SHORT = ["вс", "пн", "вт", "ср", "чт", "пт", "сб"];

export function weekdayIndex(dateStr: string): number {
  const [y, m, d] = dateStr.split("-").map(Number);
  return new Date(Date.UTC(y, m - 1, d)).getUTCDay();
}
export const weekdayFull = (s: string) => WD_FULL[weekdayIndex(s)];
export const weekdayShort = (s: string) => WD_SHORT[weekdayIndex(s)];

export function formatRu(dateStr: string): string {
  const [, m, d] = dateStr.split("-");
  return `${d}.${m} (${weekdayShort(dateStr)})`;
}

export function addMinutesLocal(local: string, minutes: number): string {
  const m = LOCAL_RE.exec(local)!;
  const [y, mo, d, h, mi] = m.slice(1).map(Number);
  const t = new Date(Date.UTC(y, mo - 1, d, h, mi + minutes));
  return t.toISOString().slice(0, 16);
}
