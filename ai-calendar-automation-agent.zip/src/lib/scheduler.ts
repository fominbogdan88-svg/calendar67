import { and, asc, eq, gte, lt } from "drizzle-orm";
import { db } from "@/db";
import { lessons, sentNotifications, sources } from "@/db/schema";
import { syncPendingGoogle } from "./google";
import { errMsg, logEvent } from "./log";
import { getSettings, type Settings } from "./settings";
import { runSource } from "./sync";
import { esc, tgSend } from "./telegram";
import { addDays, localToUtc, toLocalParts } from "./time";

// Фоновый планировщик: работает, пока запущено приложение (окно можно свернуть).
// Каждую минуту: досинхронизация с Google, напоминания в Telegram, утренняя сводка, чтение сайтов по расписанию.

const g = globalThis as typeof globalThis & { __schedStarted?: boolean; __schedBusy?: boolean; __srcBusy?: boolean };

export function startScheduler() {
  if (g.__schedStarted) return;
  g.__schedStarted = true;
  setTimeout(() => void tick(), 15_000);
  setInterval(() => void tick(), 60_000);
}

async function claim(key: string): Promise<boolean> {
  const r = await db.insert(sentNotifications).values({ key }).onConflictDoNothing().returning();
  return r.length > 0;
}

async function reminders(s: Settings) {
  if (s.tgReminders !== "true" || !s.tgToken || !s.tgChatId) return;
  const mins = Math.max(1, Number(s.tgReminderMinutes) || 30);
  const now = new Date();
  const rows = await db
    .select()
    .from(lessons)
    .where(and(eq(lessons.status, "active"), gte(lessons.startsAt, now), lt(lessons.startsAt, new Date(now.getTime() + mins * 60_000))));
  for (const l of rows) {
    const key = `rem:${l.id}:${l.startsAt.getTime()}`;
    if (!(await claim(key))) continue;
    const st = toLocalParts(l.startsAt, s.timezone).time;
    const en = toLocalParts(l.endsAt, s.timezone).time;
    const left = Math.max(1, Math.round((l.startsAt.getTime() - now.getTime()) / 60_000));
    const r = await tgSend(`⏰ <b>Через ${left} мин</b>: ${esc(l.title)}\n🕒 ${st}–${en}${l.link ? `\n🔗 ${esc(l.link)}` : ""}`);
    if (!r.ok) await db.delete(sentNotifications).where(eq(sentNotifications.key, key));
  }
}

async function digest(s: Settings) {
  if (s.tgDigest !== "true" || !s.tgToken || !s.tgChatId) return;
  const now = toLocalParts(new Date(), s.timezone);
  const [dh, dm] = (s.tgDigestTime || "08:00").split(":").map(Number);
  const [nh, nm] = now.time.split(":").map(Number);
  const diff = nh * 60 + nm - (dh * 60 + (dm || 0));
  if (diff < 0 || diff > 180) return;
  const key = `digest:${now.date}`;
  if (!(await claim(key))) return;
  const from = localToUtc(`${now.date}T00:00`, s.timezone);
  const to = localToUtc(`${addDays(now.date, 1)}T00:00`, s.timezone);
  const rows = await db
    .select()
    .from(lessons)
    .where(and(eq(lessons.status, "active"), gte(lessons.startsAt, from), lt(lessons.startsAt, to)))
    .orderBy(asc(lessons.startsAt));
  const text = rows.length
    ? `🗓 <b>Сегодня уроков: ${rows.length}</b>\n` +
      rows.map((l) => `• ${toLocalParts(l.startsAt, s.timezone).time}–${toLocalParts(l.endsAt, s.timezone).time} ${esc(l.title)}`).join("\n")
    : "🗓 Сегодня уроков нет. Хорошего дня!";
  const r = await tgSend(text);
  if (!r.ok) await db.delete(sentNotifications).where(eq(sentNotifications.key, key));
}

async function dueSources() {
  if (g.__srcBusy) return;
  g.__srcBusy = true;
  try {
    const rows = await db.select().from(sources).where(eq(sources.enabled, true));
    for (const src of rows) {
      if (src.intervalMinutes <= 0) continue;
      const due = !src.lastRunAt || Date.now() - src.lastRunAt.getTime() >= src.intervalMinutes * 60_000;
      if (!due) continue;
      try {
        await runSource(src.id);
      } catch (e) {
        await logEvent("error", `Автопроверка «${src.name}»: ${errMsg(e)}`);
      }
    }
  } finally {
    g.__srcBusy = false;
  }
}

async function tick() {
  if (g.__schedBusy) return;
  g.__schedBusy = true;
  try {
    const s = await getSettings();
    if (s.backgroundEnabled !== "true") return;
    await syncPendingGoogle().catch((e) => logEvent("warn", `Google sync: ${errMsg(e)}`));
    await reminders(s).catch((e) => logEvent("warn", `Напоминания: ${errMsg(e)}`));
    await digest(s).catch((e) => logEvent("warn", `Сводка: ${errMsg(e)}`));
    void dueSources().catch(() => undefined);
  } catch {
    // БД может быть ещё не готова
  } finally {
    g.__schedBusy = false;
  }
}
