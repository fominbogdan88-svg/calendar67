import { errMsg, sleep, UserError } from "./log";
import { getSettings, type Settings } from "./settings";

export type LlmMsg = {
  role: "system" | "user" | "assistant";
  content: string;
  /** data:image/...;base64,... */
  images?: string[];
};

const stripThink = (s: string) => s.replace(/<think>[\s\S]*?<\/think>/g, "").trim();
const rawBase64 = (d: string) => d.replace(/^data:[^;]+;base64,/, "");

async function postJson(url: string, body: unknown, headers: Record<string, string>, timeoutMs: number, tries = 2): Promise<Response> {
  let last: unknown;
  for (let i = 0; i < tries; i++) {
    try {
      const r = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json", ...headers },
        body: JSON.stringify(body),
        signal: AbortSignal.timeout(timeoutMs),
      });
      if (r.status === 429 || r.status >= 500) {
        last = new Error(`HTTP ${r.status}: ${(await r.text()).slice(0, 300)}`);
        if (r.status !== 429 && i === tries - 1) throw last;
      } else return r;
    } catch (e) {
      last = e;
    }
    await sleep(1000 * (i + 1));
  }
  throw last instanceof Error ? last : new Error("Нет связи");
}

export async function listOllamaModels(url: string): Promise<string[]> {
  const r = await fetch(`${url.replace(/\/$/, "")}/api/tags`, { signal: AbortSignal.timeout(5000) });
  if (!r.ok) throw new Error(`HTTP ${r.status}`);
  const j = (await r.json()) as { models?: { name: string }[] };
  return (j.models ?? []).map((m) => m.name);
}

async function ollamaChat(
  s: Settings,
  model: string,
  messages: LlmMsg[],
  o: { schema?: object; json: boolean; numCtx: number },
): Promise<string> {
  const base = s.ollamaUrl.replace(/\/$/, "");
  const msgs = messages.map((m) => ({
    role: m.role,
    content: m.content,
    ...(m.images?.length ? { images: m.images.map(rawBase64) } : {}),
  }));
  // У Qwen3 режим «размышлений» ломает JSON — отключаем.
  if (/qwen3/i.test(model)) {
    for (let i = msgs.length - 1; i >= 0; i--) {
      if (msgs[i].role === "user") {
        msgs[i] = { ...msgs[i], content: msgs[i].content + " /no_think" };
        break;
      }
    }
  }
  let r: Response;
  try {
    r = await postJson(
      `${base}/api/chat`,
      {
        model,
        messages: msgs,
        stream: false,
        think: false,
        ...(o.json ? { format: o.schema ?? "json" } : {}),
        options: { temperature: 0.1, num_ctx: o.numCtx },
      },
      {},
      300_000,
    );
  } catch (e) {
    throw new UserError(
      `Не удаётся связаться с Ollama (${base}). Запущена ли программа Ollama? Проверьте значок в трее или выполните «ollama serve». Детали: ${errMsg(e)}`,
    );
  }
  if (!r.ok) {
    const t = await r.text();
    if (r.status === 404 || /not found/i.test(t)) {
      throw new UserError(`Модель «${model}» не найдена в Ollama. Выполните в терминале: ollama pull ${model}`);
    }
    throw new UserError(`Ollama вернула ошибку ${r.status}: ${t.slice(0, 300)}`);
  }
  const j = (await r.json()) as { message?: { content?: string } };
  return stripThink(j.message?.content ?? "");
}

async function openaiChat(s: Settings, messages: LlmMsg[], o: { json: boolean }): Promise<string> {
  if (!s.openaiKey && !/localhost|127\.0\.0\.1/.test(s.openaiBaseUrl)) {
    throw new UserError("Не указан API-ключ. Откройте Настройки → ИИ и вставьте ключ.");
  }
  const msgs = messages.map((m) =>
    m.images?.length
      ? {
          role: m.role,
          content: [
            { type: "text", text: m.content },
            ...m.images.map((u) => ({ type: "image_url", image_url: { url: u } })),
          ],
        }
      : { role: m.role, content: m.content },
  );
  const url = `${s.openaiBaseUrl.replace(/\/$/, "")}/chat/completions`;
  const headers: Record<string, string> = s.openaiKey ? { Authorization: `Bearer ${s.openaiKey}` } : {};
  const send = (withFormat: boolean) =>
    postJson(
      url,
      { model: s.openaiModel, messages: msgs, temperature: 0.1, ...(withFormat && o.json ? { response_format: { type: "json_object" } } : {}) },
      headers,
      180_000,
    );
  let r: Response;
  try {
    r = await send(true);
    if (r.status === 400 && o.json) r = await send(false);
  } catch (e) {
    throw new UserError(`Не удаётся связаться с ИИ-сервисом: ${errMsg(e)}`);
  }
  if (!r.ok) {
    const t = await r.text();
    if (r.status === 401) throw new UserError("API-ключ не принят (ошибка 401). Проверьте ключ в Настройках.");
    throw new UserError(`ИИ-сервис вернул ошибку ${r.status}: ${t.slice(0, 300)}`);
  }
  const j = (await r.json()) as { choices?: { message?: { content?: string } }[] };
  return stripThink(j.choices?.[0]?.message?.content ?? "");
}

const VISION_PROMPT =
  "Перепиши ТОЧНО весь текст расписания с изображения. Одна строка — один урок: дата (или день недели), время начала и конца, название предмета, преподаватель/ссылка если есть. Ничего не придумывай и не пропускай. Если изображение не про расписание — коротко опиши, что на нём.";

async function transcribe(s: Settings, images: string[]): Promise<string> {
  if (!s.ollamaVisionModel) {
    throw new UserError(
      `Модель «${s.ollamaModel}» не умеет читать картинки (она текстовая). Установите модель со зрением, например: ollama pull qwen2.5vl:7b — и укажите её в Настройках → ИИ → «Модель для картинок». Либо переключитесь на облачный режим (gpt-4o-mini и т.п.).`,
    );
  }
  const out: string[] = [];
  for (let i = 0; i < images.length; i++) {
    const t = await ollamaChat(s, s.ollamaVisionModel, [{ role: "user", content: VISION_PROMPT, images: [images[i]] }], {
      json: false,
      numCtx: 8192,
    });
    out.push(`[Текст, распознанный с картинки ${i + 1}]\n${t}`);
  }
  return out.join("\n\n");
}

/** Единая точка вызова модели. Возвращает текст ответа (обычно JSON). */
export async function llmChat(opts: { messages: LlmMsg[]; schema?: object; numCtx?: number; json?: boolean }): Promise<string> {
  const s = await getSettings();
  const json = opts.json !== false;
  if (s.aiProvider === "manual") throw new UserError("Ручной режим: вызов модели выполняется через веб-чат.");
  if (s.aiProvider === "openai") return openaiChat(s, opts.messages, { json });

  // Ollama: если есть картинки — сначала превращаем их в текст моделью со зрением.
  const messages: LlmMsg[] = [];
  for (const m of opts.messages) {
    if (m.images?.length) {
      const text = await transcribe(s, m.images);
      messages.push({ role: m.role, content: `${m.content}\n\n${text}` });
    } else messages.push(m);
  }
  return ollamaChat(s, s.ollamaModel, messages, { schema: opts.schema, json, numCtx: opts.numCtx ?? 8192 });
}
