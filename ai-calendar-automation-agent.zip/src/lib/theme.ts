export const ACCENTS = ["#00e599", "#3b82f6", "#8b5cf6", "#f43f5e", "#f59e0b", "#06b6d4", "#ec4899", "#84cc16"];

export type ThemeMode = "dark" | "light" | "system";

export function accentFg(hex: string): string {
  const n = parseInt(hex.replace("#", ""), 16);
  const r = (n >> 16) & 255;
  const g = (n >> 8) & 255;
  const b = n & 255;
  return (0.299 * r + 0.587 * g + 0.114 * b) / 255 > 0.6 ? "#000000" : "#ffffff";
}

export function applyAccent(hex: string) {
  const el = document.documentElement;
  el.style.setProperty("--accent", hex);
  el.style.setProperty("--accent-fg", accentFg(hex));
}

export function resolveTheme(mode: ThemeMode): "dark" | "light" {
  if (mode === "system") return window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
  return mode;
}

export function applyTheme(mode: ThemeMode) {
  document.documentElement.dataset.theme = resolveTheme(mode);
}

export function loadTheme(): { mode: ThemeMode; accent: string } {
  const mode = (localStorage.getItem("theme") as ThemeMode) || "dark";
  const accent = localStorage.getItem("accent") || ACCENTS[0];
  return { mode, accent };
}

export function saveTheme(mode: ThemeMode, accent: string) {
  localStorage.setItem("theme", mode);
  localStorage.setItem("accent", accent);
}

/** Скрипт, который выполняется до отрисовки страницы — чтобы не было «мигания» темы. */
export const THEME_INIT_SCRIPT = `(function(){try{var t=localStorage.getItem('theme')||'dark';var d=t==='system'?(matchMedia('(prefers-color-scheme: dark)').matches?'dark':'light'):t;var e=document.documentElement;e.dataset.theme=d;var a=localStorage.getItem('accent');if(a&&/^#[0-9a-fA-F]{6}$/.test(a)){var n=parseInt(a.slice(1),16),r=n>>16&255,g=n>>8&255,b=n&255;e.style.setProperty('--accent',a);e.style.setProperty('--accent-fg',(0.299*r+0.587*g+0.114*b)/255>0.6?'#000000':'#ffffff')}}catch(x){}})();`;
