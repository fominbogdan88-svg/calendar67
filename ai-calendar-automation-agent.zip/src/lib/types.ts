import type { lessons } from "@/db/schema";

export type Lesson = typeof lessons.$inferSelect;

export type NormOp = {
  op: "add" | "update" | "cancel" | "restore";
  lessonId?: number;
  title?: string;
  /** локальное время в часовом поясе пользователя: YYYY-MM-DDTHH:mm */
  start?: string;
  end?: string;
  link?: string;
  notes?: string;
  label: string;
  warnings: string[];
};

export type LessonView = {
  id: number;
  title: string;
  date: string;
  start: string;
  end: string;
  endDate: string;
  status: string;
  link: string;
  notes: string;
  origin: string;
  sourceId: number | null;
  synced: boolean;
};
