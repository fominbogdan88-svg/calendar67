// Устойчивый разбор JSON из ответа языковой модели (маленькие модели часто «ломают» формат).

export function parseModelJson(text: string): unknown | null {
  let s = text.replace(/<think>[\s\S]*?<\/think>/g, "").trim();
  s = s.replace(/^```(?:json)?/i, "").replace(/```$/i, "").trim();
  const candidates: string[] = [s];
  const a = s.indexOf("{");
  const b = s.lastIndexOf("}");
  if (a >= 0 && b > a) candidates.push(s.slice(a, b + 1));
  for (const c of candidates) {
    for (const variant of [c, c.replace(/,\s*([}\]])/g, "$1"), c.replace(/,\s*([}\]])/g, "$1").replace(/[“”]/g, '"')]) {
      try {
        return JSON.parse(variant);
      } catch {
        // пробуем следующий вариант
      }
    }
  }
  return null;
}
