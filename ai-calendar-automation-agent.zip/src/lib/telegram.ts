import { errMsg, sleep } from "./log";
import { randomCode } from "./crypto";
import { getSettings, saveSettings } from "./settings";

export const esc = (s: string) => s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");

type TgResp<T> = { ok: boolean; result?: T; description?: string; parameters?: { retry_after?: number } };

async function tg<T>(token: string, method: string, body: Record<string, unknown> = {}, tries = 3): Promise<TgResp<T>> {
  let last: unknown;
  for (let i = 0; i < tries; i++) {
    try {
      const r = await fetch(`https://api.telegram.org/bot${token}/${method}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
        signal: AbortSignal.timeout(20000),
      });
      const j = (await r.json()) as TgResp<T>;
      if (r.status === 429) {
        await sleep(((j.parameters?.retry_after ?? 2) + 1) * 1000);
        continue;
      }
      return j;
    } catch (e) {
      last = e;
      await sleep(800 * (i + 1));
    }
  }
  return { ok: false, description: errMsg(last) };
}

/** Отправка уведомления. Текст — HTML (пользовательские данные нужно пропускать через esc). */
export async function tgSend(html: string): Promise<{ ok: boolean; error?: string }> {
  const s = await getSettings();
  if (!s.tgToken || !s.tgChatId) return { ok: false, error: "Telegram не настроен" };
  const r = await tg(s.tgToken, "sendMessage", {
    chat_id: s.tgChatId,
    text: html.slice(0, 4000),
    parse_mode: "HTML",
    disable_web_page_preview: true,
  });
  return r.ok ? { ok: true } : { ok: false, error: r.description || "ошибка Telegram" };
}

export async function tgBindStart(): Promise<{ ok: boolean; code?: string; bot?: string; error?: string }> {
  const s = await getSettings();
  if (!s.tgToken) return { ok: false, error: "Сначала вставьте токен бота и сохраните настройки." };
  const me = await tg<{ username: string }>(s.tgToken, "getMe");
  if (!me.ok) return { ok: false, error: `Токен не подошёл: ${me.description}` };
  const code = randomCode(6);
  await saveSettings({ tgBindCode: code, tgChatId: "" });
  return { ok: true, code, bot: me.result?.username };
}

/** Привязка чата по одноразовому коду: берём только сообщение, содержащее код, из личного чата. */
export async function tgBindCheck(): Promise<{ bound: boolean; error?: string }> {
  const s = await getSettings();
  if (!s.tgToken || !s.tgBindCode) return { bound: false, error: "Сначала нажмите «Получить код»." };
  await tg(s.tgToken, "deleteWebhook", {}, 1);
  const r = await tg<{ update_id: number; message?: { text?: string; chat: { id: number; type: string } } }[]>(
    s.tgToken,
    "getUpdates",
    { offset: Number(s.tgUpdateOffset) || 0, timeout: 0, allowed_updates: ["message"] },
  );
  if (!r.ok) return { bound: false, error: r.description };
  let maxId = Number(s.tgUpdateOffset) || 0;
  let chatId: number | null = null;
  for (const u of r.result ?? []) {
    maxId = Math.max(maxId, u.update_id + 1);
    const m = u.message;
    if (m && m.chat.type === "private" && m.text && m.text.toUpperCase().includes(s.tgBindCode.toUpperCase())) {
      chatId = m.chat.id;
    }
  }
  if (chatId === null) {
    await saveSettings({ tgUpdateOffset: String(maxId) });
    return { bound: false };
  }
  await saveSettings({ tgChatId: String(chatId), tgBindCode: "", tgUpdateOffset: String(maxId) });
  await tgSend("✅ Бот подключён. Сюда будут приходить напоминания об уроках.");
  return { bound: true };
}
