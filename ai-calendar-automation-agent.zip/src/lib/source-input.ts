import type { sources } from "@/db/schema";
import { UserError } from "./log";

export function parseSourceInput(b: Record<string, unknown>, partial: boolean) {
  const out: Partial<typeof sources.$inferInsert> = {};
  if (b.name !== undefined || !partial) {
    const name = String(b.name ?? "").trim();
    if (!name) throw new UserError("Укажите название");
    out.name = name.slice(0, 100);
  }
  if (b.url !== undefined || !partial) {
    const url = String(b.url ?? "").trim();
    try {
      const u = new URL(url);
      if (!/^https?:$/.test(u.protocol)) throw new Error();
    } catch {
      throw new UserError("Адрес должен начинаться с http:// или https://");
    }
    out.url = url;
  }
  if (b.selector !== undefined) out.selector = String(b.selector).trim().slice(0, 300);
  if (b.enabled !== undefined) out.enabled = !!b.enabled;
  if (b.autoApply !== undefined) out.autoApply = !!b.autoApply;
  if (b.intervalMinutes !== undefined) {
    const n = Math.round(Number(b.intervalMinutes));
    if (!(n >= 0 && n <= 10080)) throw new UserError("Интервал — от 0 до 10080 минут (0 = только вручную)");
    out.intervalMinutes = n;
  }
  return out;
}

