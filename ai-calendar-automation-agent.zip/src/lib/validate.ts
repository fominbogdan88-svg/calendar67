import { addMinutesLocal, formatRu, isRealLocal, localToUtc, toLocalParts, toLocalString } from "./time";
import type { Lesson, NormOp } from "./types";

// Все данные от ИИ проверяются программой — модели нельзя доверять слепо.

export type RawOp = Record<string, unknown>;

export function normTitle(s: string): string {
  return s.toLowerCase().replace(/ё/g, "е").replace(/[^\p{L}\p{N}]+/gu, " ").trim();
}

export function normTime(v: unknown): string | null {
  if (typeof v !== "string" && typeof v !== "number") return null;
  const s = String(v).trim().replace(".", ":").replace(/[hч]$/i, "");
  const m = /^(\d{1,2})(?::(\d{2}))?$/.exec(s);
  if (!m) return null;
  const h = Number(m[1]);
  const mi = m[2] ? Number(m[2]) : 0;
  if (h > 23 || mi > 59) return null;
  return `${String(h).padStart(2, "0")}:${String(mi).padStart(2, "0")}`;
}

export function normDate(v: unknown): string | null {
  if (typeof v !== "string") return null;
  const s = v.trim();
  const m = /^(\d{4})-(\d{1,2})-(\d{1,2})$/.exec(s);
  if (!m) return null;
  const iso = `${m[1]}-${m[2].padStart(2, "0")}-${m[3].padStart(2, "0")}`;
  return isRealLocal(`${iso}T00:00`) ? iso : null;
}

export function describeTimes(start: string, end: string): string {
  const d = start.slice(0, 10);
  return `${formatRu(d)} ${start.slice(11)}–${end.slice(11)}`;
}

export type ValidateCtx = {
  tz: string;
  lessons: Lesson[]; // активные и отменённые уроки
  defaultDuration: number;
};

export type LessonFields = {
  title: string;
  date: string;
  start: string;
  end: string;
  link?: string;
  notes?: string;
};

/** Проверяет и нормализует данные одного урока (дата, время, длительность). */
export function validateFields(
  r: Record<string, unknown>,
  defaultDuration: number,
): { ok: true; value: LessonFields } | { ok: false; error: string } {
  const title = typeof r.title === "string" ? r.title.trim() : "";
  if (!title) return { ok: false, error: "нет названия урока" };
  if (title.length > 200) return { ok: false, error: `слишком длинное название «${title.slice(0, 30)}…»` };
  const date = normDate(r.date);
  if (!date) return { ok: false, error: `«${title}»: дата «${String(r.date)}» не похожа на ГГГГ-ММ-ДД` };
  const year = Number(date.slice(0, 4));
  const nowYear = new Date().getFullYear();
  if (year < nowYear - 1 || year > nowYear + 2) return { ok: false, error: `«${title}»: подозрительный год ${year}` };
  const st = normTime(r.start_time ?? r.start);
  if (!st) return { ok: false, error: `«${title}»: время начала «${String(r.start_time ?? r.start)}» некорректно` };
  const startLocal = `${date}T${st}`;
  let en = normTime(r.end_time ?? r.end);
  let endLocal: string;
  if (!en) endLocal = addMinutesLocal(startLocal, defaultDuration);
  else endLocal = `${date}T${en}`;
  if (endLocal <= startLocal) return { ok: false, error: `«${title}»: конец (${endLocal.slice(11)}) не позже начала (${st})` };
  if (endLocal.slice(0, 10) !== date) return { ok: false, error: `«${title}»: урок не может переходить через полночь` };
  en = endLocal.slice(11);
  const link = typeof r.link === "string" ? r.link.trim().slice(0, 500) : undefined;
  const notes = typeof r.notes === "string" ? r.notes.trim().slice(0, 1000) : undefined;
  return { ok: true, value: { title, date, start: startLocal, end: endLocal, link, notes } };
}

function overlaps(aS: string, aE: string, bS: string, bE: string): boolean {
  return aS < bE && bS < aE;
}

export function normalizeOps(
  raw: RawOp[],
  ctx: ValidateCtx,
): { ops: NormOp[]; errors: string[]; skipped: string[] } {
  const ops: NormOp[] = [];
  const errors: string[] = [];
  const skipped: string[] = [];
  const byId = new Map(ctx.lessons.map((l) => [l.id, l]));
  const localOf = (l: Lesson) => ({
    start: toLocalString(l.startsAt, ctx.tz),
    end: toLocalString(l.endsAt, ctx.tz),
  });
  const planned: { start: string; end: string; title: string; id?: number }[] = [];

  raw.slice(0, 60).forEach((r, i) => {
    if (!r || typeof r !== "object") return;
    const kind = String(r.op ?? "").toLowerCase();
    const idRaw = r.lesson_id ?? r.id;
    const lessonId = idRaw === undefined || idRaw === null || idRaw === "" ? undefined : Number(String(idRaw).replace("#", ""));
    const tag = `Операция ${i + 1}`;

    if (kind === "add") {
      const v = validateFields(r, ctx.defaultDuration);
      if (!v.ok) return void errors.push(`${tag}: ${v.error}`);
      const f = v.value;
      const dup = ctx.lessons.find(
        (l) => l.status === "active" && normTitle(l.title) === normTitle(f.title) && localOf(l).start === f.start,
      );
      if (dup || planned.some((p) => normTitle(p.title) === normTitle(f.title) && p.start === f.start)) {
        return void skipped.push(`«${f.title}» ${describeTimes(f.start, f.end)} — уже есть в расписании (дубль не создан)`);
      }
      const warnings: string[] = [];
      for (const l of ctx.lessons) {
        if (l.status !== "active") continue;
        const lo = localOf(l);
        if (overlaps(f.start, f.end, lo.start, lo.end)) warnings.push(`пересекается с «${l.title}» (${lo.start.slice(11)}–${lo.end.slice(11)})`);
      }
      if (localToUtc(f.start, ctx.tz).getTime() < Date.now() - 3600_000) warnings.push("урок в прошлом");
      planned.push({ start: f.start, end: f.end, title: f.title });
      ops.push({
        op: "add",
        title: f.title,
        start: f.start,
        end: f.end,
        link: f.link ?? "",
        notes: f.notes ?? "",
        label: `Добавить: «${f.title}» — ${describeTimes(f.start, f.end)}`,
        warnings,
      });
      return;
    }

    if (kind === "update" || kind === "cancel") {
      if (!lessonId || !Number.isInteger(lessonId) || !byId.has(lessonId)) {
        return void errors.push(`${tag}: урок с номером «${String(idRaw)}» не найден в списке`);
      }
      const cur = byId.get(lessonId)!;
      if (cur.status === "deleted") return void errors.push(`${tag}: урок #${lessonId} уже удалён`);
      const lo = localOf(cur);
      if (kind === "cancel") {
        if (cur.status === "cancelled") return void skipped.push(`«${cur.title}» уже отменён`);
        ops.push({
          op: "cancel",
          lessonId,
          label: `Отменить: «${cur.title}» — ${describeTimes(lo.start, lo.end)}`,
          warnings: [],
        });
        return;
      }
      // update: накладываем изменения на текущие значения
      const merged: Record<string, unknown> = {
        title: r.title ?? cur.title,
        date: r.date ?? lo.start.slice(0, 10),
        start_time: r.start_time ?? lo.start.slice(11),
        end_time: r.end_time ?? (r.start_time && !r.end_time ? undefined : lo.end.slice(11)),
        link: r.link ?? cur.link,
        notes: r.notes ?? cur.notes,
      };
      // при переносе только начала сохраняем длительность
      if (r.start_time && !r.end_time) {
        const dur = (cur.endsAt.getTime() - cur.startsAt.getTime()) / 60000;
        const st = normTime(r.start_time);
        const dt = normDate(merged.date);
        if (st && dt) merged.end_time = addMinutesLocal(`${dt}T${st}`, dur).slice(11);
      }
      const v = validateFields(merged, ctx.defaultDuration);
      if (!v.ok) return void errors.push(`${tag}: ${v.error}`);
      const f = v.value;
      const same =
        f.title === cur.title && f.start === lo.start && f.end === lo.end && (f.link ?? "") === cur.link && (f.notes ?? "") === cur.notes;
      if (same) return void skipped.push(`«${cur.title}»: изменений нет`);
      const warnings: string[] = [];
      for (const l of ctx.lessons) {
        if (l.status !== "active" || l.id === cur.id) continue;
        const o = localOf(l);
        if (overlaps(f.start, f.end, o.start, o.end)) warnings.push(`пересекается с «${l.title}» (${o.start.slice(11)}–${o.end.slice(11)})`);
      }
      ops.push({
        op: "update",
        lessonId,
        title: f.title,
        start: f.start,
        end: f.end,
        link: f.link ?? "",
        notes: f.notes ?? "",
        label: `Изменить: «${cur.title}» ${describeTimes(lo.start, lo.end)} → «${f.title}» ${describeTimes(f.start, f.end)}`,
        warnings,
      });
      return;
    }

    errors.push(`${tag}: неизвестное действие «${String(r.op)}»`);
  });

  return { ops, errors, skipped };
}

export { toLocalParts };
