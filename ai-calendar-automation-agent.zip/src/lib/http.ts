import { NextResponse } from "next/server";
import { errMsg, logEvent, UserError } from "./log";

/** Единая обёртка для API: защита от запросов с чужих сайтов (CSRF) + аккуратные ошибки. */
export async function wrap(req: Request, fn: () => Promise<unknown>): Promise<Response> {
  try {
    if (req.method !== "GET" && req.method !== "HEAD") {
      const origin = req.headers.get("origin");
      const host = req.headers.get("host");
      if (origin && host) {
        let oh = "";
        try {
          oh = new URL(origin).host;
        } catch {
          // ignore
        }
        const fwd = req.headers.get("x-forwarded-host");
        if (oh !== host && oh !== fwd) return NextResponse.json({ error: "Запрос отклонён (чужой источник)" }, { status: 403 });
      }
    }
    const r = await fn();
    return r instanceof Response ? r : NextResponse.json(r ?? { ok: true });
  } catch (e) {
    const user = e instanceof UserError;
    if (!user) await logEvent("error", `${new URL(req.url).pathname}: ${errMsg(e)}`);
    return NextResponse.json({ error: errMsg(e) }, { status: user ? 400 : 500 });
  }
}

export async function body<T = Record<string, unknown>>(req: Request): Promise<T> {
  try {
    return (await req.json()) as T;
  } catch {
    throw new UserError("Некорректный запрос");
  }
}
