import {
  boolean,
  index,
  integer,
  jsonb,
  pgTable,
  serial,
  text,
  timestamp,
} from "drizzle-orm/pg-core";

export const settings = pgTable("settings", {
  key: text("key").primaryKey(),
  value: text("value").notNull(),
});

export const sources = pgTable("sources", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  url: text("url").notNull(),
  selector: text("selector").notNull().default(""),
  enabled: boolean("enabled").notNull().default(true),
  intervalMinutes: integer("interval_minutes").notNull().default(60),
  autoApply: boolean("auto_apply").notNull().default(false),
  lastRunAt: timestamp("last_run_at", { withTimezone: true }),
  lastHash: text("last_hash"),
  lastStatus: text("last_status").notNull().default("never"),
  lastMessage: text("last_message").notNull().default(""),
  lastCount: integer("last_count").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const lessons = pgTable(
  "lessons",
  {
    id: serial("id").primaryKey(),
    sourceId: integer("source_id"),
    title: text("title").notNull(),
    startsAt: timestamp("starts_at", { withTimezone: true }).notNull(),
    endsAt: timestamp("ends_at", { withTimezone: true }).notNull(),
    // active | cancelled | deleted
    status: text("status").notNull().default("active"),
    link: text("link").notNull().default(""),
    notes: text("notes").notNull().default(""),
    // manual | chat | source
    origin: text("origin").notNull().default("manual"),
    googleEventId: text("google_event_id"),
    googleSyncedHash: text("google_synced_hash"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("lessons_starts_idx").on(t.startsAt)],
);

export const chatMessages = pgTable("chat_messages", {
  id: serial("id").primaryKey(),
  // user | assistant | tool
  role: text("role").notNull(),
  content: text("content").notNull(),
  kind: text("kind").notNull().default("text"),
  images: jsonb("images").$type<string[]>().notNull().default([]),
  planId: integer("plan_id"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const plans = pgTable("plans", {
  id: serial("id").primaryKey(),
  // chat | sync
  kind: text("kind").notNull().default("chat"),
  sourceId: integer("source_id"),
  // pending | applied | rejected | failed
  status: text("status").notNull().default("pending"),
  title: text("title").notNull().default(""),
  ops: jsonb("ops").$type<unknown[]>().notNull().default([]),
  result: text("result").notNull().default(""),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  resolvedAt: timestamp("resolved_at", { withTimezone: true }),
});

export const actionLog = pgTable(
  "action_log",
  {
    id: serial("id").primaryKey(),
    batchId: text("batch_id").notNull(),
    planId: integer("plan_id"),
    lessonId: integer("lesson_id").notNull(),
    op: text("op").notNull(),
    summary: text("summary").notNull().default(""),
    before: jsonb("before"),
    after: jsonb("after"),
    undone: boolean("undone").notNull().default(false),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("action_log_batch_idx").on(t.batchId)],
);

export const sentNotifications = pgTable("sent_notifications", {
  key: text("key").primaryKey(),
  sentAt: timestamp("sent_at", { withTimezone: true }).notNull().defaultNow(),
});

export const appLogs = pgTable("app_logs", {
  id: serial("id").primaryKey(),
  level: text("level").notNull().default("info"),
  message: text("message").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});
