"use client";

import { useCallback, useEffect, useState } from "react";
import { Badge, Button, Card, useToast } from "@/components/ui";
import { api } from "@/lib/client";

type Batch = { batchId: string; createdAt: string; undone: boolean; items: { op: string; summary: string; undone: boolean }[] };
type LogRow = { id: number; level: string; message: string; createdAt: string };

function batchTitle(id: string) {
  if (id.startsWith("manual")) return "Ручное изменение";
  if (id.startsWith("plan")) return "Применён план агента";
  return "Изменение";
}

export default function HistoryPage() {
  const toast = useToast();
  const [batches, setBatches] = useState<Batch[]>([]);
  const [logs, setLogs] = useState<LogRow[]>([]);
  const [busy, setBusy] = useState<string | null>(null);

  const load = useCallback(async () => {
    try {
      const r = await api<{ batches: Batch[]; logs: LogRow[] }>("/api/history");
      setBatches(r.batches);
      setLogs(r.logs);
    } catch (e) {
      toast((e as Error).message, "error");
    }
  }, [toast]);
  useEffect(() => {
    void load();
  }, [load]);

  async function undo(id: string) {
    if (!confirm("Откатить это изменение? Календарь вернётся к прежнему состоянию.")) return;
    setBusy(id);
    try {
      const r = await api<{ message: string }>("/api/history", { body: { batchId: id } });
      toast(r.message, "ok");
    } catch (e) {
      toast((e as Error).message, "error");
    } finally {
      setBusy(null);
      await load();
    }
  }

  return (
    <div className="mx-auto max-w-4xl space-y-6 px-4 py-6 sm:px-8">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">История и откат</h1>
        <p className="mt-1 text-sm text-muted">Каждое изменение записывается. Ошибочное можно отменить одной кнопкой — в Google Calendar тоже.</p>
      </div>

      {batches.length === 0 && <Card>Изменений пока не было.</Card>}
      {batches.map((b) => (
        <Card key={b.batchId}>
          <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <span className="font-semibold">{batchTitle(b.batchId)}</span>
              <span className="text-xs text-muted">{new Date(b.createdAt).toLocaleString("ru-RU")}</span>
              {b.undone && <Badge tone="warn">откатено</Badge>}
            </div>
            {!b.undone && (
              <Button size="sm" icon="undo" loading={busy === b.batchId} onClick={() => undo(b.batchId)}>
                Откатить
              </Button>
            )}
          </div>
          <ul className="space-y-1 text-sm">
            {b.items.map((i, k) => (
              <li key={k} className={i.undone ? "text-muted line-through" : ""}>
                • {i.summary}
              </li>
            ))}
          </ul>
        </Card>
      ))}

      <Card title="Журнал ошибок и событий" desc="Если что-то не работает — посмотрите сюда: здесь написана причина.">
        {logs.length === 0 ? (
          <p className="text-sm text-muted">Записей нет.</p>
        ) : (
          <ul className="max-h-96 space-y-1.5 overflow-y-auto text-xs">
            {logs.map((l) => (
              <li key={l.id} className="flex gap-2">
                <span className="shrink-0 text-muted">{new Date(l.createdAt).toLocaleString("ru-RU")}</span>
                <Badge tone={l.level === "error" ? "danger" : l.level === "warn" ? "warn" : "muted"}>{l.level}</Badge>
                <span className="min-w-0 break-words">{l.message}</span>
              </li>
            ))}
          </ul>
        )}
      </Card>
    </div>
  );
}
