import type { MetadataRoute } from "next";

// Позволяет установить сайт как отдельное приложение (Edge/Chrome → «Установить»).
export default function manifest(): MetadataRoute.Manifest {
  return {
    name: "Расписание онлайн-уроков",
    short_name: "Расписание",
    description: "ИИ-агент для расписания онлайн-уроков",
    start_url: "/",
    display: "standalone",
    background_color: "#000000",
    theme_color: "#000000",
    icons: [{ src: "/icon.svg", sizes: "any", type: "image/svg+xml", purpose: "any" }],
  };
}
