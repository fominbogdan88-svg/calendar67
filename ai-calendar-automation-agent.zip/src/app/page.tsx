"use client";

import Link from "next/link";
import { useCallback, useEffect, useMemo, useState } from "react";
import PendingPlans from "@/components/PendingPlans";
import { Badge, Button, Field, Icon, Input, Modal, Spinner, Textarea, useToast } from "@/components/ui";
import { api, colorFor } from "@/lib/client";
import { addDays, formatRu, todayLocal, weekdayIndex } from "@/lib/time";
import type { LessonView } from "@/lib/types";

const ROW = 56; // px на час
const MONTHS = ["января", "февраля", "марта", "апреля", "мая", "июня", "июля", "августа", "сентября", "октября", "ноября", "декабря"];

function mondayOf(date: string): string {
  const wd = (weekdayIndex(date) + 6) % 7;
  return addDays(date, -wd);
}
const toMin = (t: string) => Number(t.slice(0, 2)) * 60 + Number(t.slice(3, 5));

type Placed = LessonView & { lane: number; lanes: number };

function layout(day: LessonView[]): Placed[] {
  const sorted = [...day].sort((a, b) => toMin(a.start) - toMin(b.start));
  const out: Placed[] = [];
  let group: Placed[] = [];
  let groupEnd = -1;
  const flush = () => {
    const n = Math.max(1, ...group.map((g) => g.lane + 1));
    group.forEach((g) => (g.lanes = n));
    out.push(...group);
    group = [];
  };
  const laneEnds: number[] = [];
  for (const l of sorted) {
    const s = toMin(l.start);
    const e = l.endDate === l.date ? toMin(l.end) : 24 * 60;
    if (s >= groupEnd && group.length) {
      flush();
      laneEnds.length = 0;
    }
    let lane = laneEnds.findIndex((x) => x <= s);
    if (lane === -1) lane = laneEnds.length;
    laneEnds[lane] = e;
    group.push({ ...l, lane, lanes: 1 });
    groupEnd = Math.max(groupEnd, e);
  }
  if (group.length) flush();
  return out;
}

type Form = { id?: number; title: string; date: string; start_time: string; end_time: string; link: string; notes: string };

export default function CalendarPage() {
  const toast = useToast();
  const [tz, setTz] = useState("");
  const [today, setToday] = useState("");
  const [weekStart, setWeekStart] = useState("");
  const [items, setItems] = useState<LessonView[]>([]);
  const [loading, setLoading] = useState(true);
  const [form, setForm] = useState<Form | null>(null);
  const [current, setCurrent] = useState<LessonView | null>(null);
  const [saving, setSaving] = useState(false);
  const [syncing, setSyncing] = useState(false);
  const [now, setNow] = useState("");

  useEffect(() => {
    api<{ timezone: string }>("/api/status")
      .then((s) => {
        setTz(s.timezone);
        const t = todayLocal(s.timezone);
        setToday(t);
        setWeekStart(mondayOf(t));
      })
      .catch((e) => toast(e.message, "error"));
  }, [toast]);

  const load = useCallback(async () => {
    if (!weekStart) return;
    setLoading(true);
    try {
      const r = await api<{ lessons: LessonView[] }>(`/api/lessons?from=${weekStart}&to=${addDays(weekStart, 7)}`);
      setItems(r.lessons);
    } catch (e) {
      toast((e as Error).message, "error");
    } finally {
      setLoading(false);
    }
  }, [weekStart, toast]);
  useEffect(() => {
    void load();
  }, [load]);

  useEffect(() => {
    if (!tz) return;
    const upd = () => {
      const d = new Date();
      const p = new Intl.DateTimeFormat("en-GB", { timeZone: tz, hour: "2-digit", minute: "2-digit", hourCycle: "h23" }).format(d);
      setNow(p);
    };
    upd();
    const id = setInterval(upd, 30000);
    return () => clearInterval(id);
  }, [tz]);

  const days = useMemo(() => (weekStart ? Array.from({ length: 7 }, (_, i) => addDays(weekStart, i)) : []), [weekStart]);

  const { startH, endH } = useMemo(() => {
    let s = 8;
    let e = 21;
    for (const l of items) {
      s = Math.min(s, Math.floor(toMin(l.start) / 60));
      e = Math.max(e, Math.ceil((l.endDate === l.date ? toMin(l.end) : 1440) / 60));
    }
    return { startH: s, endH: Math.min(24, e) };
  }, [items]);

  const [wy, wm, wd] = weekStart ? weekStart.split("-").map(Number) : [0, 1, 1];
  const endDay = weekStart ? addDays(weekStart, 6) : "";
  const rangeLabel = weekStart ? `${wd} ${MONTHS[wm - 1]}${endDay.slice(5, 7) !== weekStart.slice(5, 7) ? "" : ""} — ${Number(endDay.slice(8))} ${MONTHS[Number(endDay.slice(5, 7)) - 1]} ${endDay.slice(0, 4)}` : "";
  void wy;

  function openNew(date?: string, hour?: number) {
    const d = date ?? today;
    const h = hour ?? 15;
    setCurrent(null);
    setForm({ title: "", date: d, start_time: `${String(h).padStart(2, "0")}:00`, end_time: `${String(Math.min(h + 1, 23)).padStart(2, "0")}:00`, link: "", notes: "" });
  }
  function openEdit(l: LessonView) {
    setCurrent(l);
    setForm({ id: l.id, title: l.title, date: l.date, start_time: l.start, end_time: l.end, link: l.link, notes: l.notes });
  }

  async function save() {
    if (!form) return;
    setSaving(true);
    try {
      const r = await api<{ message?: string; warnings?: string[] }>(form.id ? `/api/lessons/${form.id}` : "/api/lessons", {
        method: form.id ? "PATCH" : "POST",
        body: form,
      });
      toast(`${form.id ? "Сохранено" : "Урок добавлен"}. ${r.message ?? ""}${r.warnings?.length ? ` ⚠ ${r.warnings.join("; ")}` : ""}`, "ok");
      setForm(null);
      await load();
    } catch (e) {
      toast((e as Error).message, "error");
    } finally {
      setSaving(false);
    }
  }

  async function action(a: "cancel" | "restore") {
    if (!form?.id) return;
    setSaving(true);
    try {
      const r = await api<{ message?: string }>(`/api/lessons/${form.id}`, { method: "PATCH", body: { action: a } });
      toast(`${a === "cancel" ? "Урок отменён" : "Урок восстановлен"}. ${r.message ?? ""}`, "ok");
      setForm(null);
      await load();
    } catch (e) {
      toast((e as Error).message, "error");
    } finally {
      setSaving(false);
    }
  }

  async function syncGoogle() {
    setSyncing(true);
    try {
      const r = await api<{ message: string; ok: boolean }>("/api/google/action", { body: { action: "sync" } });
      toast(r.message, r.ok ? "ok" : "error");
      await load();
    } catch (e) {
      toast((e as Error).message, "error");
    } finally {
      setSyncing(false);
    }
  }

  const activeCount = items.filter((i) => i.status === "active").length;
  const unsynced = items.filter((i) => !i.synced).length;
  const nowMin = now ? toMin(now) : 0;

  return (
    <div className="mx-auto max-w-[1400px] px-4 py-6 sm:px-8">
      <div className="mb-5 flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Календарь</h1>
          <p className="mt-1 text-sm text-muted">
            {rangeLabel} · уроков на неделе: {activeCount} · пояс: {tz || "…"}
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <Button size="sm" variant="secondary" onClick={() => setWeekStart(addDays(weekStart, -7))} aria-label="Назад">
            <Icon name="chevL" size={16} />
          </Button>
          <Button size="sm" variant="secondary" onClick={() => setWeekStart(mondayOf(today))}>
            Сегодня
          </Button>
          <Button size="sm" variant="secondary" onClick={() => setWeekStart(addDays(weekStart, 7))} aria-label="Вперёд">
            <Icon name="chevR" size={16} />
          </Button>
          <Button size="sm" variant="secondary" icon="refresh" loading={syncing} onClick={syncGoogle}>
            Синхронизировать с Google{unsynced ? ` (${unsynced})` : ""}
          </Button>
          <Button variant="primary" icon="plus" onClick={() => openNew()}>
            Урок
          </Button>
        </div>
      </div>

      <PendingPlans onChange={load} />

      {!loading && items.length === 0 && (
        <div className="mb-6 rounded-lg border border-dashed border-line p-6 text-center text-sm text-muted">
          На этой неделе уроков нет. Загрузите расписание с сайта школы (<Link href="/sources" className="text-link underline">Источники</Link>), пришлите картинку в{" "}
          <Link href="/chat" className="text-link underline">чат с агентом</Link> или добавьте урок вручную. Не знаете, с чего начать? Откройте{" "}
          <Link href="/guide" className="text-link underline">Инструкцию</Link>.
        </div>
      )}

      <div className="relative overflow-x-auto rounded-lg border border-line bg-panel">
        {loading && (
          <div className="absolute right-3 top-3 z-20 text-muted">
            <Spinner />
          </div>
        )}
        <div className="min-w-[860px]">
          <div className="grid grid-cols-[56px_repeat(7,1fr)] border-b border-line">
            <div />
            {days.map((d) => (
              <div key={d} className={`border-l border-line px-2 py-2 text-center text-sm ${d === today ? "text-link" : "text-muted"}`}>
                <div className="font-semibold">{formatRu(d).split(" ")[1].replace(/[()]/g, "").toUpperCase()}</div>
                <div className={`mx-auto mt-0.5 flex h-7 w-7 items-center justify-center rounded-full text-sm ${d === today ? "bg-accent font-bold text-accent-fg" : "text-fg"}`}>{Number(d.slice(8))}</div>
              </div>
            ))}
          </div>
          <div className="relative grid grid-cols-[56px_repeat(7,1fr)]" style={{ height: (endH - startH) * ROW }}>
            <div className="relative">
              {Array.from({ length: endH - startH }, (_, i) => (
                <div key={i} className="absolute right-2 -translate-y-2 text-[11px] text-muted" style={{ top: i * ROW }}>
                  {i > 0 ? `${String(startH + i).padStart(2, "0")}:00` : ""}
                </div>
              ))}
            </div>
            {days.map((d) => {
              const dayItems = layout(items.filter((l) => l.date === d));
              return (
                <div
                  key={d}
                  className="relative cursor-pointer border-l border-line"
                  onDoubleClick={(e) => {
                    const rect = e.currentTarget.getBoundingClientRect();
                    openNew(d, startH + Math.floor((e.clientY - rect.top) / ROW));
                  }}
                  title="Двойной клик — добавить урок"
                >
                  {Array.from({ length: endH - startH }, (_, i) => (
                    <div key={i} className="absolute inset-x-0 border-t border-line/60" style={{ top: i * ROW }} />
                  ))}
                  {d === today && nowMin >= startH * 60 && nowMin <= endH * 60 && (
                    <div className="pointer-events-none absolute inset-x-0 z-10 border-t-2 border-accent" style={{ top: ((nowMin - startH * 60) / 60) * ROW }}>
                      <span className="absolute -left-1 -top-1.5 h-2.5 w-2.5 rounded-full bg-accent" />
                    </div>
                  )}
                  {dayItems.map((l) => {
                    const top = ((toMin(l.start) - startH * 60) / 60) * ROW;
                    const h = Math.max(26, (((l.endDate === l.date ? toMin(l.end) : 1440) - toMin(l.start)) / 60) * ROW - 2);
                    const hue = colorFor(l.title);
                    const cancelled = l.status === "cancelled";
                    return (
                      <button
                        key={l.id}
                        onClick={(e) => {
                          e.stopPropagation();
                          openEdit(l);
                        }}
                        onDoubleClick={(e) => e.stopPropagation()}
                        className={`absolute z-[5] cursor-pointer overflow-hidden rounded-md border-l-4 px-1.5 py-1 text-left text-xs transition hover:brightness-125 ${cancelled ? "opacity-50" : ""}`}
                        style={{
                          top,
                          height: h,
                          left: `calc(${(l.lane / l.lanes) * 100}% + 2px)`,
                          width: `calc(${100 / l.lanes}% - 4px)`,
                          background: `hsl(${hue} 70% 50% / 0.2)`,
                          borderColor: `hsl(${hue} 70% 55%)`,
                        }}
                      >
                        <div className={`truncate font-semibold ${cancelled ? "line-through" : ""}`}>{l.title}</div>
                        <div className="truncate text-[11px] text-muted">
                          {l.start}–{l.end}
                          {cancelled ? " · отменён" : ""}
                          {!l.synced ? " · ⏳" : ""}
                        </div>
                      </button>
                    );
                  })}
                </div>
              );
            })}
          </div>
        </div>
      </div>
      <p className="mt-3 text-xs text-muted">Подсказки: клик по уроку — редактировать, двойной клик по пустому месту — добавить. ⏳ — ещё не отправлено в Google Calendar.</p>

      <Modal open={!!form} onClose={() => setForm(null)} title={form?.id ? "Урок" : "Новый урок"}>
        {form && (
          <div className="space-y-3">
            {current && (
              <div className="flex flex-wrap gap-2">
                <Badge tone={current.status === "active" ? "ok" : "warn"}>{current.status === "active" ? "активен" : "отменён"}</Badge>
                <Badge>{current.origin === "source" ? "с сайта школы" : current.origin === "chat" ? "из чата" : "вручную"}</Badge>
                <Badge tone={current.synced ? "ok" : "warn"}>{current.synced ? "в Google ✓" : "ещё не в Google"}</Badge>
              </div>
            )}
            <Field label="Название">
              <Input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} placeholder="Например: Математика" autoFocus />
            </Field>
            <div className="grid grid-cols-3 gap-3">
              <Field label="Дата">
                <Input type="date" value={form.date} onChange={(e) => setForm({ ...form, date: e.target.value })} />
              </Field>
              <Field label="Начало">
                <Input type="time" value={form.start_time} onChange={(e) => setForm({ ...form, start_time: e.target.value })} />
              </Field>
              <Field label="Конец">
                <Input type="time" value={form.end_time} onChange={(e) => setForm({ ...form, end_time: e.target.value })} />
              </Field>
            </div>
            <Field label="Ссылка на урок (необязательно)">
              <Input value={form.link} onChange={(e) => setForm({ ...form, link: e.target.value })} placeholder="https://..." />
            </Field>
            <Field label="Заметки">
              <Textarea rows={2} value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} />
            </Field>
            <div className="flex flex-wrap items-center justify-between gap-2 pt-2">
              <div>
                {form.id && current?.status === "active" && (
                  <Button variant="danger" icon="trash" onClick={() => action("cancel")} disabled={saving}>
                    Отменить урок
                  </Button>
                )}
                {form.id && current?.status === "cancelled" && (
                  <Button variant="secondary" icon="undo" onClick={() => action("restore")} disabled={saving}>
                    Восстановить
                  </Button>
                )}
              </div>
              <div className="flex gap-2">
                <Button variant="ghost" onClick={() => setForm(null)}>
                  Закрыть
                </Button>
                <Button variant="primary" loading={saving} onClick={save}>
                  Сохранить
                </Button>
              </div>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
}
