import { wrap } from "@/lib/http";
import { listOllamaModels } from "@/lib/llm";
import { errMsg } from "@/lib/log";
import { getSettings } from "@/lib/settings";

export const dynamic = "force-dynamic";

export function GET(req: Request) {
  return wrap(req, async () => {
    const s = await getSettings();
    const url = new URL(req.url).searchParams.get("url") || s.ollamaUrl;
    try {
      return { ok: true, models: await listOllamaModels(url) };
    } catch (e) {
      return { ok: false, models: [], error: `Ollama не отвечает по адресу ${url} (${errMsg(e)}). Запустите Ollama и повторите.` };
    }
  });
}
