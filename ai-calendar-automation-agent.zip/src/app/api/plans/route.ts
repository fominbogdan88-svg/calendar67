import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { plans } from "@/db/schema";
import { wrap } from "@/lib/http";

export const dynamic = "force-dynamic";

export function GET(req: Request) {
  return wrap(req, async () => {
    const rows = await db.select().from(plans).where(eq(plans.status, "pending")).orderBy(desc(plans.id));
    return { plans: rows };
  });
}
