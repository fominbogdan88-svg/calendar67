import { body, wrap } from "@/lib/http";
import { UserError } from "@/lib/log";
import { applyPlan, rejectPlan } from "@/lib/plans";

export const dynamic = "force-dynamic";

export function POST(req: Request, { params }: { params: Promise<{ id: string }> }) {
  return wrap(req, async () => {
    const id = Number((await params).id);
    const b = await body<{ action?: string }>(req);
    if (b.action === "apply") return { ok: true, message: await applyPlan(id) };
    if (b.action === "reject") {
      await rejectPlan(id);
      return { ok: true };
    }
    throw new UserError("Неизвестное действие");
  });
}
