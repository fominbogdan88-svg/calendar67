import { desc } from "drizzle-orm";
import { db } from "@/db";
import { actionLog, appLogs } from "@/db/schema";
import { googleSummary, syncPendingGoogle } from "@/lib/google";
import { body, wrap } from "@/lib/http";
import { undoBatch } from "@/lib/lessons";
import { UserError } from "@/lib/log";
import { addMessage } from "@/lib/plans";

export const dynamic = "force-dynamic";

export function GET(req: Request) {
  return wrap(req, async () => {
    const rows = await db.select().from(actionLog).orderBy(desc(actionLog.id)).limit(400);
    const map = new Map<string, { batchId: string; createdAt: Date; items: { op: string; summary: string; undone: boolean }[] }>();
    for (const r of rows) {
      if (!map.has(r.batchId)) map.set(r.batchId, { batchId: r.batchId, createdAt: r.createdAt, items: [] });
      map.get(r.batchId)!.items.unshift({ op: r.op, summary: r.summary, undone: r.undone });
    }
    const logs = await db.select().from(appLogs).orderBy(desc(appLogs.id)).limit(100);
    return {
      batches: [...map.values()].map((b) => ({ ...b, undone: b.items.every((i) => i.undone) })),
      logs,
    };
  });
}

export function POST(req: Request) {
  return wrap(req, async () => {
    const b = await body<{ batchId?: string }>(req);
    if (!b.batchId) throw new UserError("Не указана пачка изменений");
    const n = await undoBatch(b.batchId);
    const g = await syncPendingGoogle();
    await addMessage("tool", `Пользователь откатил последние изменения (${n} шт.). ${googleSummary(g)}`, { kind: "result" });
    return { ok: true, message: `Откачено изменений: ${n}. ${googleSummary(g)}` };
  });
}
