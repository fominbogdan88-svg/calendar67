import { wrap } from "@/lib/http";
import { runSource } from "@/lib/sync";

export const dynamic = "force-dynamic";
export const maxDuration = 600;

export function POST(req: Request, { params }: { params: Promise<{ id: string }> }) {
  return wrap(req, async () => {
    const id = Number((await params).id);
    const r = await runSource(id, { force: true });
    return { ok: true, ...r };
  });
}
