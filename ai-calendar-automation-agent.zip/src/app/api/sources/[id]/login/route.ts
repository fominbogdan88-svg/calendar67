import { eq } from "drizzle-orm";
import { db } from "@/db";
import { sources } from "@/db/schema";
import { wrap } from "@/lib/http";
import { UserError } from "@/lib/log";
import { openLoginBrowser } from "@/lib/scraper";

export const dynamic = "force-dynamic";

export function POST(req: Request, { params }: { params: Promise<{ id: string }> }) {
  return wrap(req, async () => {
    const id = Number((await params).id);
    const [src] = await db.select().from(sources).where(eq(sources.id, id));
    if (!src) throw new UserError("Источник не найден");
    await openLoginBrowser(src.url);
    return { ok: true, message: "Окно браузера открыто. Войдите на сайте школы, затем закройте это окно — вход запомнится." };
  });
}
