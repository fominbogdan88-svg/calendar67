import { eq } from "drizzle-orm";
import { db } from "@/db";
import { sources } from "@/db/schema";
import { body, wrap } from "@/lib/http";
import { parseSourceInput } from "@/lib/source-input";

export const dynamic = "force-dynamic";

export function PATCH(req: Request, { params }: { params: Promise<{ id: string }> }) {
  return wrap(req, async () => {
    const id = Number((await params).id);
    const b = await body<Record<string, unknown>>(req);
    const v = parseSourceInput(b, true);
    // при смене адреса/селектора сбрасываем «отпечаток» страницы
    if (v.url !== undefined || v.selector !== undefined) Object.assign(v, { lastHash: null });
    if (Object.keys(v).length) await db.update(sources).set(v).where(eq(sources.id, id));
    return { ok: true };
  });
}

export function DELETE(req: Request, { params }: { params: Promise<{ id: string }> }) {
  return wrap(req, async () => {
    const id = Number((await params).id);
    await db.delete(sources).where(eq(sources.id, id));
    return { ok: true };
  });
}
