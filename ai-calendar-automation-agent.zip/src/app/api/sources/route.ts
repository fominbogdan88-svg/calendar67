import { desc } from "drizzle-orm";
import { db } from "@/db";
import { sources } from "@/db/schema";
import { body, wrap } from "@/lib/http";
import { parseSourceInput } from "@/lib/source-input";

export const dynamic = "force-dynamic";

export function GET(req: Request) {
  return wrap(req, async () => ({ sources: await db.select().from(sources).orderBy(desc(sources.id)) }));
}

export function POST(req: Request) {
  return wrap(req, async () => {
    const b = await body<Record<string, unknown>>(req);
    const v = parseSourceInput(b, false);
    await db.insert(sources).values(v as typeof sources.$inferInsert);
    return { ok: true };
  });
}
