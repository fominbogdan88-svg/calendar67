import { desc, inArray } from "drizzle-orm";
import { db } from "@/db";
import { chatMessages, plans, sources } from "@/db/schema";
import { handleManualAnswer, handleUserMessage } from "@/lib/agent";
import { body, wrap } from "@/lib/http";
import { UserError } from "@/lib/log";
import { getSettings } from "@/lib/settings";

export const dynamic = "force-dynamic";
export const maxDuration = 300;

export function GET(req: Request) {
  return wrap(req, async () => {
    const s = await getSettings();
    const rows = (await db.select().from(chatMessages).orderBy(desc(chatMessages.id)).limit(60)).reverse();
    const planIds = [...new Set(rows.map((r) => r.planId).filter((x): x is number => x !== null))];
    const ps = planIds.length ? await db.select().from(plans).where(inArray(plans.id, planIds)) : [];
    void sources;
    return {
      provider: s.aiProvider,
      model: s.aiProvider === "ollama" ? s.ollamaModel : s.aiProvider === "openai" ? s.openaiModel : "веб-чат (вручную)",
      messages: rows.map((m) => ({
        id: m.id,
        role: m.role,
        content: m.content,
        kind: m.kind,
        images: m.images,
        createdAt: m.createdAt,
        plan: m.planId ? ps.find((p) => p.id === m.planId) ?? null : null,
      })),
    };
  });
}

export function POST(req: Request) {
  return wrap(req, async () => {
    const b = await body<{ text?: string; images?: string[]; manualAnswer?: string }>(req);
    if (b.manualAnswer) {
      await handleManualAnswer(String(b.manualAnswer).slice(0, 50000));
      return { ok: true };
    }
    const text = String(b.text ?? "").trim().slice(0, 8000);
    const images = (Array.isArray(b.images) ? b.images : []).filter((x) => typeof x === "string" && /^data:image\/(png|jpe?g|webp|gif);base64,/.test(x) && x.length < 12_000_000).slice(0, 4);
    if (!text && !images.length) throw new UserError("Напишите сообщение или приложите картинку");
    await handleUserMessage(text, images);
    return { ok: true };
  });
}

export function DELETE(req: Request) {
  return wrap(req, async () => {
    await db.delete(chatMessages);
    return { ok: true };
  });
}
