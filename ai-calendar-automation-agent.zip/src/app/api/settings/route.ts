import { body, wrap } from "@/lib/http";
import { googleConnected, googleConfigured } from "@/lib/google";
import { UserError } from "@/lib/log";
import { getSettings, publicSettings, saveSettings } from "@/lib/settings";
import { isValidTz } from "@/lib/time";

export const dynamic = "force-dynamic";

export function GET(req: Request) {
  return wrap(req, async () => {
    const s = await getSettings();
    return {
      settings: publicSettings(s),
      googleConfigured: googleConfigured(s),
      googleConnected: googleConnected(s),
      telegramBound: !!(s.tgToken && s.tgChatId),
    };
  });
}

export function POST(req: Request) {
  return wrap(req, async () => {
    const patch = await body<Record<string, string>>(req);
    if (patch.timezone !== undefined && !isValidTz(String(patch.timezone))) throw new UserError("Неизвестный часовой пояс");
    if (patch.tgDigestTime !== undefined && !/^\d{1,2}:\d{2}$/.test(String(patch.tgDigestTime))) throw new UserError("Время сводки — в формате ЧЧ:ММ");
    for (const k of ["tgReminderMinutes", "defaultDuration"]) {
      if (patch[k] !== undefined && !(Number(patch[k]) > 0 && Number(patch[k]) <= 1440)) throw new UserError("Число минут должно быть от 1 до 1440");
    }
    const clean: Record<string, string> = {};
    for (const [k, v] of Object.entries(patch)) clean[k] = typeof v === "string" ? v.trim() : String(v);
    await saveSettings(clean);
    return { ok: true };
  });
}
