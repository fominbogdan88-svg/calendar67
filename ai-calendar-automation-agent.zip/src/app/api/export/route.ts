import { db } from "@/db";
import { sources } from "@/db/schema";
import { body, wrap } from "@/lib/http";
import { UserError } from "@/lib/log";
import { DEFAULTS, getSettings, saveSettings, SECRET_KEYS } from "@/lib/settings";

export const dynamic = "force-dynamic";

// Экспорт настроек БЕЗ секретов (токены, ключи, пароли не выгружаются).
export function GET(req: Request) {
  return wrap(req, async () => {
    const s = await getSettings();
    const safe: Record<string, string> = {};
    for (const k of Object.keys(DEFAULTS)) {
      if (SECRET_KEYS.has(k) || ["googleCalendarId", "tgChatId", "tgBindCode", "tgUpdateOffset", "googleRedirectOrigin"].includes(k)) continue;
      safe[k] = s[k];
    }
    const src = (await db.select().from(sources)).map((x) => ({
      name: x.name,
      url: x.url,
      selector: x.selector,
      enabled: x.enabled,
      intervalMinutes: x.intervalMinutes,
      autoApply: x.autoApply,
    }));
    return { version: 1, settings: safe, sources: src };
  });
}

export function POST(req: Request) {
  return wrap(req, async () => {
    const b = await body<{ settings?: Record<string, string>; sources?: { name: string; url: string; selector?: string; enabled?: boolean; intervalMinutes?: number; autoApply?: boolean }[] }>(req);
    if (!b.settings && !b.sources) throw new UserError("Файл не похож на экспорт настроек");
    const patch: Record<string, string> = {};
    for (const [k, v] of Object.entries(b.settings ?? {})) if (k in DEFAULTS && !SECRET_KEYS.has(k)) patch[k] = String(v);
    await saveSettings(patch);
    const existing = new Set((await db.select().from(sources)).map((x) => x.url));
    let added = 0;
    for (const x of b.sources ?? []) {
      if (!x?.url || !x?.name || existing.has(x.url)) continue;
      await db.insert(sources).values({
        name: String(x.name).slice(0, 100),
        url: String(x.url),
        selector: String(x.selector ?? ""),
        enabled: x.enabled !== false,
        intervalMinutes: Number(x.intervalMinutes) >= 0 ? Number(x.intervalMinutes) : 60,
        autoApply: !!x.autoApply,
      });
      added++;
    }
    return { ok: true, message: `Настройки импортированы, источников добавлено: ${added}. Ключи и токены нужно ввести заново.` };
  });
}
