import { and, gte, lt, ne } from "drizzle-orm";
import { db } from "@/db";
import { lessons } from "@/db/schema";
import { syncPendingGoogle, googleSummary } from "@/lib/google";
import { body, wrap } from "@/lib/http";
import { applyOps, toView } from "@/lib/lessons";
import { UserError } from "@/lib/log";
import { getSettings } from "@/lib/settings";
import { addDays, localToUtc, todayLocal } from "@/lib/time";
import { normalizeOps } from "@/lib/validate";

export const dynamic = "force-dynamic";

export function GET(req: Request) {
  return wrap(req, async () => {
    const s = await getSettings();
    const u = new URL(req.url);
    const today = todayLocal(s.timezone);
    const re = /^\d{4}-\d{2}-\d{2}$/;
    const from = re.test(u.searchParams.get("from") ?? "") ? u.searchParams.get("from")! : addDays(today, -7);
    const to = re.test(u.searchParams.get("to") ?? "") ? u.searchParams.get("to")! : addDays(today, 60);
    const rows = await db
      .select()
      .from(lessons)
      .where(and(ne(lessons.status, "deleted"), gte(lessons.startsAt, localToUtc(`${from}T00:00`, s.timezone)), lt(lessons.startsAt, localToUtc(`${to}T00:00`, s.timezone))))
      .orderBy(lessons.startsAt);
    return { tz: s.timezone, today, lessons: rows.map((l) => toView(l, s.timezone)) };
  });
}

export function POST(req: Request) {
  return wrap(req, async () => {
    const b = await body<Record<string, unknown>>(req);
    const s = await getSettings();
    const all = await db.select().from(lessons).where(ne(lessons.status, "deleted"));
    const n = normalizeOps([{ ...b, op: "add" }], { tz: s.timezone, lessons: all, defaultDuration: Number(s.defaultDuration) || 60 });
    if (n.errors.length) throw new UserError(n.errors.join("; "));
    if (!n.ops.length) return { ok: true, message: n.skipped.join("; ") || "Ничего не добавлено" };
    await applyOps(n.ops, { batchId: `manual-${Date.now()}`, origin: "manual", tz: s.timezone });
    const g = await syncPendingGoogle();
    return { ok: true, message: googleSummary(g), warnings: n.ops[0].warnings };
  });
}
