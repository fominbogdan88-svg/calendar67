import { ne } from "drizzle-orm";
import { db } from "@/db";
import { lessons } from "@/db/schema";
import { googleSummary, syncPendingGoogle } from "@/lib/google";
import { body, wrap } from "@/lib/http";
import { applyOps } from "@/lib/lessons";
import { UserError } from "@/lib/log";
import { getSettings } from "@/lib/settings";
import type { NormOp } from "@/lib/types";
import { normalizeOps } from "@/lib/validate";

export const dynamic = "force-dynamic";

export function PATCH(req: Request, { params }: { params: Promise<{ id: string }> }) {
  return wrap(req, async () => {
    const id = Number((await params).id);
    const b = await body<Record<string, unknown>>(req);
    const s = await getSettings();
    const all = await db.select().from(lessons).where(ne(lessons.status, "deleted"));
    const cur = all.find((l) => l.id === id);
    if (!cur) throw new UserError("Урок не найден");
    let ops: NormOp[] = [];
    let skipped = "";
    if (b.action === "restore") {
      ops = [{ op: "restore", lessonId: id, label: `Восстановить: «${cur.title}»`, warnings: [] }];
    } else {
      const op = b.action === "cancel" ? "cancel" : "update";
      const n = normalizeOps([{ ...b, op, lesson_id: id }], { tz: s.timezone, lessons: all, defaultDuration: Number(s.defaultDuration) || 60 });
      if (n.errors.length) throw new UserError(n.errors.join("; "));
      ops = n.ops;
      skipped = n.skipped.join("; ");
    }
    if (!ops.length) return { ok: true, message: skipped || "Изменений нет" };
    await applyOps(ops, { batchId: `manual-${Date.now()}`, origin: "manual", tz: s.timezone });
    const g = await syncPendingGoogle();
    return { ok: true, message: googleSummary(g), warnings: ops[0].warnings };
  });
}
