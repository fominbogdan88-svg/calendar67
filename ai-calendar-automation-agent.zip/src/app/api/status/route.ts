import { count, eq } from "drizzle-orm";
import { db } from "@/db";
import { plans, sources } from "@/db/schema";
import { googleConnected } from "@/lib/google";
import { wrap } from "@/lib/http";
import { getSettings } from "@/lib/settings";

export const dynamic = "force-dynamic";

export function GET(req: Request) {
  return wrap(req, async () => {
    const s = await getSettings();
    const [p] = await db.select({ n: count() }).from(plans).where(eq(plans.status, "pending"));
    const [src] = await db.select({ n: count() }).from(sources);
    return {
      pendingPlans: p.n,
      sources: src.n,
      google: googleConnected(s),
      telegram: !!(s.tgToken && s.tgChatId),
      provider: s.aiProvider,
      timezone: s.timezone,
    };
  });
}
