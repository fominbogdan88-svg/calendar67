import { NextResponse } from "next/server";
import { exchangeCode, syncPendingGoogle } from "@/lib/google";
import { errMsg } from "@/lib/log";
import { getSettings } from "@/lib/settings";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  const u = new URL(req.url);
  const s = await getSettings();
  const origin = s.googleRedirectOrigin || u.origin;
  const back = (q: string) => NextResponse.redirect(new URL(`/settings?${q}`, origin));
  const code = u.searchParams.get("code");
  if (!code) return back(`google=error&msg=${encodeURIComponent(u.searchParams.get("error") || "Доступ не выдан")}`);
  try {
    await exchangeCode(code, origin);
    await syncPendingGoogle().catch(() => undefined);
    return back("google=ok");
  } catch (e) {
    return back(`google=error&msg=${encodeURIComponent(errMsg(e))}`);
  }
}
