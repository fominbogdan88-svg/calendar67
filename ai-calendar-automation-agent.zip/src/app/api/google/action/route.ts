import { eq, ne } from "drizzle-orm";
import { db } from "@/db";
import { lessons } from "@/db/schema";
import { disconnectGoogle, googleSummary, syncPendingGoogle } from "@/lib/google";
import { body, wrap } from "@/lib/http";
import { UserError } from "@/lib/log";

export const dynamic = "force-dynamic";

export function POST(req: Request) {
  return wrap(req, async () => {
    const b = await body<{ action?: string }>(req);
    if (b.action === "disconnect") {
      await disconnectGoogle();
      // события из старого календаря больше не привязаны
      await db.update(lessons).set({ googleEventId: null, googleSyncedHash: null }).where(ne(lessons.id, -1));
      return { ok: true, message: "Google отключён" };
    }
    if (b.action === "sync") {
      const g = await syncPendingGoogle();
      return { ok: g.failed === 0, message: googleSummary(g) };
    }
    if (b.action === "resync") {
      await db.update(lessons).set({ googleSyncedHash: null }).where(eq(lessons.status, "active"));
      const g = await syncPendingGoogle();
      return { ok: g.failed === 0, message: googleSummary(g) };
    }
    throw new UserError("Неизвестное действие");
  });
}
