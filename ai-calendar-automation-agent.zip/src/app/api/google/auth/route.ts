import { NextResponse } from "next/server";
import { buildAuthUrl, googleConfigured } from "@/lib/google";
import { getSettings, saveSettings } from "@/lib/settings";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  const u = new URL(req.url);
  const s = await getSettings();
  const origin = u.searchParams.get("origin") || u.origin;
  if (!googleConfigured(s)) {
    return NextResponse.redirect(new URL("/settings?google=noconfig", origin));
  }
  await saveSettings({ googleRedirectOrigin: origin });
  return NextResponse.redirect(buildAuthUrl(s, origin));
}
