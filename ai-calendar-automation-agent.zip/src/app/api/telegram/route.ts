import { body, wrap } from "@/lib/http";
import { UserError } from "@/lib/log";
import { tgBindCheck, tgBindStart, tgSend } from "@/lib/telegram";

export const dynamic = "force-dynamic";

export function POST(req: Request) {
  return wrap(req, async () => {
    const b = await body<{ action?: string }>(req);
    if (b.action === "test") {
      const r = await tgSend("🔔 Тестовое уведомление от «Расписание онлайн-уроков». Всё работает!");
      if (!r.ok) throw new UserError(r.error || "Не удалось отправить");
      return { ok: true, message: "Сообщение отправлено — проверьте Telegram." };
    }
    if (b.action === "bind-start") {
      const r = await tgBindStart();
      if (!r.ok) throw new UserError(r.error || "Ошибка");
      return r;
    }
    if (b.action === "bind-check") return tgBindCheck();
    throw new UserError("Неизвестное действие");
  });
}
