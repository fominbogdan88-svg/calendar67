"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { Badge, Button, Card, Field, Icon, Input, Select, Toggle, useToast } from "@/components/ui";
import { api } from "@/lib/client";

type S = Record<string, string>;
type Resp = { settings: S; googleConnected: boolean; googleConfigured: boolean; telegramBound: boolean };

const MODES = [
  { id: "ollama", title: "Локально на компьютере", sub: "Ollama + Qwen и др. Бесплатно, данные не уходят в облако.", icon: "shield" },
  { id: "openai", title: "Облачный API", sub: "OpenAI, OpenRouter, Gemini, LM Studio — любой совместимый сервис.", icon: "sparkles" },
  { id: "manual", title: "Веб-версия вручную", sub: "ChatGPT/Claude/Gemini в браузере: копируете запрос и ответ.", icon: "copy" },
];

const PRESETS = [
  { name: "OpenAI", url: "https://api.openai.com/v1", model: "gpt-4o-mini" },
  { name: "OpenRouter", url: "https://openrouter.ai/api/v1", model: "openai/gpt-4o-mini" },
  { name: "Google Gemini", url: "https://generativelanguage.googleapis.com/v1beta/openai", model: "gemini-2.0-flash" },
  { name: "LM Studio (локально)", url: "http://127.0.0.1:1234/v1", model: "qwen2.5-14b-instruct" },
];

const SECTIONS = [
  ["ai", "Искусственный интеллект"],
  ["google", "Google Calendar"],
  ["telegram", "Telegram"],
  ["auto", "Автоматизация"],
  ["backup", "Копия настроек"],
];

export default function SettingsPage() {
  const toast = useToast();
  const [s, setS] = useState<S | null>(null);
  const [gConn, setGConn] = useState(false);
  const [tgBound, setTgBound] = useState(false);
  const [saving, setSaving] = useState(false);
  const [models, setModels] = useState<string[]>([]);
  const [checking, setChecking] = useState(false);
  const [origin, setOrigin] = useState("");
  const [bind, setBind] = useState<{ code: string; bot?: string } | null>(null);
  const [busy, setBusy] = useState<string | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const dirty = useRef(false);

  const load = useCallback(async () => {
    const r = await api<Resp>("/api/settings");
    setS(r.settings);
    setGConn(r.googleConnected);
    setTgBound(r.telegramBound);
    dirty.current = false;
  }, []);

  useEffect(() => {
    setOrigin(window.location.origin);
    load().catch((e) => toast(e.message, "error"));
    const q = new URLSearchParams(window.location.search);
    if (q.get("google") === "ok") toast("Google Calendar подключён!", "ok");
    if (q.get("google") === "error") toast(`Google: ${q.get("msg") ?? "ошибка"}`, "error");
    if (q.get("google") === "noconfig") toast("Сначала вставьте Client ID и Client secret и сохраните", "error");
  }, [load, toast]);

  // автопроверка привязки Telegram
  useEffect(() => {
    if (!bind) return;
    const id = setInterval(async () => {
      try {
        const r = await api<{ bound: boolean }>("/api/telegram", { body: { action: "bind-check" } });
        if (r.bound) {
          setBind(null);
          toast("Telegram подключён!", "ok");
          await load();
        }
      } catch {
        // повторим
      }
    }, 3000);
    return () => clearInterval(id);
  }, [bind, load, toast]);

  if (!s) return <div className="p-8 text-muted">Загрузка…</div>;

  const set = (k: string, v: string) => {
    dirty.current = true;
    setS((x) => ({ ...(x as S), [k]: v }));
  };
  const bool = (k: string) => s[k] === "true";

  async function save(silent = false) {
    setSaving(true);
    try {
      await api("/api/settings", { body: s });
      await load();
      if (!silent) toast("Настройки сохранены", "ok");
      return true;
    } catch (e) {
      toast((e as Error).message, "error");
      return false;
    } finally {
      setSaving(false);
    }
  }

  async function run(key: string, fn: () => Promise<void>) {
    setBusy(key);
    try {
      await fn();
    } catch (e) {
      toast((e as Error).message, "error");
    } finally {
      setBusy(null);
    }
  }

  async function checkOllama() {
    setChecking(true);
    try {
      const r = await api<{ ok: boolean; models: string[]; error?: string }>(`/api/ollama?url=${encodeURIComponent(s!.ollamaUrl)}`);
      setModels(r.models);
      if (r.ok) toast(`Ollama работает. Найдено моделей: ${r.models.length}`, "ok");
      else toast(r.error ?? "Ollama не отвечает", "error");
    } finally {
      setChecking(false);
    }
  }

  const tzList: string[] = typeof Intl !== "undefined" && "supportedValuesOf" in Intl ? (Intl as unknown as { supportedValuesOf: (k: string) => string[] }).supportedValuesOf("timeZone") : [];
  const redirect = `${origin}/api/google/callback`;

  return (
    <div className="mx-auto flex max-w-6xl gap-10 px-4 py-6 sm:px-8">
      <div className="min-w-0 flex-1 space-y-6">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Настройки</h1>
            <p className="mt-1 text-sm text-muted">Ключи и токены хранятся на вашем компьютере в зашифрованном виде.</p>
          </div>
          <Button variant="primary" icon="check" loading={saving} onClick={() => save()}>
            Сохранить
          </Button>
        </div>

        <Card id="ai" title="Искусственный интеллект" desc="Выберите, какой «мозг» будет понимать ваши просьбы и читать расписание.">
          <div className="grid gap-3 md:grid-cols-3">
            {MODES.map((m) => (
              <button
                key={m.id}
                onClick={() => set("aiProvider", m.id)}
                className={`cursor-pointer rounded-lg border p-4 text-left transition ${s.aiProvider === m.id ? "border-accent bg-accent/10" : "border-line hover:bg-panel2"}`}
              >
                <Icon name={m.icon} className={s.aiProvider === m.id ? "text-link" : "text-muted"} />
                <div className="mt-2 text-sm font-semibold">{m.title}</div>
                <div className="mt-1 text-xs text-muted leading-relaxed">{m.sub}</div>
              </button>
            ))}
          </div>

          {s.aiProvider === "ollama" && (
            <div className="mt-5 space-y-4">
              <div className="grid gap-4 sm:grid-cols-2">
                <Field label="Адрес Ollama" hint="Обычно менять не нужно.">
                  <Input value={s.ollamaUrl} onChange={(e) => set("ollamaUrl", e.target.value)} />
                </Field>
                <Field label="Основная модель" hint="Для текста. Подойдёт qwen3:8b; надёжнее — qwen2.5:14b.">
                  <Input list="ollama-models" value={s.ollamaModel} onChange={(e) => set("ollamaModel", e.target.value)} />
                </Field>
              </div>
              <Field label="Модель для картинок (со «зрением»)" hint="qwen3:8b картинки НЕ видит. Для скриншотов расписания установите, например, qwen2.5vl:7b командой «ollama pull qwen2.5vl:7b» и впишите её сюда.">
                <Input list="ollama-models" value={s.ollamaVisionModel} onChange={(e) => set("ollamaVisionModel", e.target.value)} placeholder="qwen2.5vl:7b" />
              </Field>
              <datalist id="ollama-models">
                {models.map((m) => (
                  <option key={m} value={m} />
                ))}
              </datalist>
              <div className="flex flex-wrap items-center gap-2">
                <Button icon="refresh" loading={checking} onClick={checkOllama}>
                  Проверить Ollama и показать модели
                </Button>
                {models.length > 0 && models.map((m) => <Badge key={m}>{m}</Badge>)}
              </div>
            </div>
          )}

          {s.aiProvider === "openai" && (
            <div className="mt-5 space-y-4">
              <div className="flex flex-wrap gap-2">
                {PRESETS.map((p) => (
                  <Button
                    key={p.name}
                    size="sm"
                    onClick={() => {
                      set("openaiBaseUrl", p.url);
                      set("openaiModel", p.model);
                    }}
                  >
                    {p.name}
                  </Button>
                ))}
              </div>
              <div className="grid gap-4 sm:grid-cols-2">
                <Field label="Адрес API">
                  <Input value={s.openaiBaseUrl} onChange={(e) => set("openaiBaseUrl", e.target.value)} />
                </Field>
                <Field label="Модель" hint="Должна уметь читать картинки, если вы хотите присылать скриншоты (gpt-4o-mini умеет).">
                  <Input value={s.openaiModel} onChange={(e) => set("openaiModel", e.target.value)} />
                </Field>
              </div>
              <Field label="API-ключ" hint="Хранится в зашифрованном виде. Внимание: текст страниц и картинки отправляются выбранному сервису.">
                <Input type="password" value={s.openaiKey} onChange={(e) => set("openaiKey", e.target.value)} placeholder="sk-..." autoComplete="off" />
              </Field>
            </div>
          )}

          {s.aiProvider === "manual" && (
            <p className="mt-5 rounded-md border border-line bg-bg p-4 text-sm text-muted leading-relaxed">
              В этом режиме приложение не обращается к ИИ само. В чате оно подготовит запрос — вы вставите его в обычную веб-версию ChatGPT/Claude/Gemini, а ответ скопируете обратно. Подписка на веб-чат
              подходит, API-ключ не нужен. Автоматическое чтение сайтов в этом режиме недоступно.
            </p>
          )}
        </Card>

        <Card id="google" title="Google Calendar" desc="Приложение создаст отдельный календарь «Онлайн-уроки» и будет менять только его — ваши личные события в безопасности.">
          <div className="mb-4 flex items-center gap-2">
            <Badge tone={gConn ? "ok" : "warn"}>{gConn ? "подключён" : "не подключён"}</Badge>
            <Toggle checked={bool("googlePush")} onChange={(v) => set("googlePush", String(v))} label="" />
            <span className="text-sm text-muted">Отправлять уроки в Google</span>
          </div>
          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="Client ID">
              <Input value={s.googleClientId} onChange={(e) => set("googleClientId", e.target.value)} placeholder="123456-abc.apps.googleusercontent.com" />
            </Field>
            <Field label="Client secret">
              <Input type="password" value={s.googleClientSecret} onChange={(e) => set("googleClientSecret", e.target.value)} autoComplete="off" />
            </Field>
          </div>
          <Field label="Redirect URI (скопируйте в Google Cloud)" hint="Именно этот адрес нужно вставить в «Authorized redirect URIs». Пошаговая инструкция — в разделе «Инструкция».">
            <div className="flex gap-2">
              <Input readOnly value={redirect} />
              <Button icon="copy" onClick={() => navigator.clipboard.writeText(redirect).then(() => toast("Скопировано", "ok"))} aria-label="Копировать" />
            </div>
          </Field>
          <div className="mt-4 flex flex-wrap gap-2">
            <Button
              variant="primary"
              icon="link"
              loading={busy === "gconnect"}
              onClick={() =>
                run("gconnect", async () => {
                  if (await save(true)) window.location.href = `/api/google/auth?origin=${encodeURIComponent(window.location.origin)}`;
                })
              }
            >
              {gConn ? "Подключить заново" : "Подключить Google"}
            </Button>
            {gConn && (
              <>
                <Button
                  icon="refresh"
                  loading={busy === "gsync"}
                  onClick={() =>
                    run("gsync", async () => {
                      const r = await api<{ message: string; ok: boolean }>("/api/google/action", { body: { action: "resync" } });
                      toast(r.message, r.ok ? "ok" : "error");
                    })
                  }
                >
                  Отправить всё заново
                </Button>
                <Button
                  variant="danger"
                  loading={busy === "gdisc"}
                  onClick={() =>
                    run("gdisc", async () => {
                      if (!confirm("Отключить Google? Календарь в Google останется, но приложение перестанет его менять.")) return;
                      await api("/api/google/action", { body: { action: "disconnect" } });
                      await load();
                    })
                  }
                >
                  Отключить
                </Button>
              </>
            )}
          </div>
        </Card>

        <Card id="telegram" title="Telegram-уведомления" desc="Напоминания об уроках, утренняя сводка и сообщения об изменениях расписания.">
          <div className="mb-4 flex items-center gap-2">
            <Badge tone={tgBound ? "ok" : "warn"}>{tgBound ? "чат привязан" : "не привязан"}</Badge>
          </div>
          <Field label="Токен бота" hint="Его выдаёт @BotFather (см. инструкцию). Хранится в зашифрованном виде.">
            <Input type="password" value={s.tgToken} onChange={(e) => set("tgToken", e.target.value)} placeholder="123456:ABC-DEF..." autoComplete="off" />
          </Field>
          <div className="mt-4 flex flex-wrap gap-2">
            <Button
              icon="link"
              loading={busy === "tgbind"}
              onClick={() =>
                run("tgbind", async () => {
                  if (!(await save(true))) return;
                  const r = await api<{ code: string; bot?: string }>("/api/telegram", { body: { action: "bind-start" } });
                  setBind({ code: r.code, bot: r.bot });
                })
              }
            >
              Привязать мой чат
            </Button>
            <Button icon="bell" loading={busy === "tgtest"} disabled={!tgBound} onClick={() => run("tgtest", async () => toast((await api<{ message: string }>("/api/telegram", { body: { action: "test" } })).message, "ok"))}>
              Отправить тест
            </Button>
          </div>
          {bind && (
            <div className="mt-4 rounded-lg border border-accent/40 bg-accent/5 p-4 text-sm leading-relaxed">
              <div className="font-semibold">Почти готово!</div>
              <ol className="mt-2 list-decimal space-y-1 pl-5 text-muted">
                <li>
                  Откройте своего бота {bind.bot ? <a className="text-link underline" href={`https://t.me/${bind.bot}`} target="_blank" rel="noreferrer">@{bind.bot}</a> : ""} в Telegram.
                </li>
                <li>
                  Отправьте ему сообщение: <code className="rounded bg-panel2 px-1.5 py-0.5 font-mono text-fg">/start {bind.code}</code>
                </li>
                <li>Эта страница сама заметит привязку (проверка каждые 3 секунды).</li>
              </ol>
            </div>
          )}
          <div className="mt-5 grid gap-x-8 sm:grid-cols-2">
            <div>
              <Toggle checked={bool("tgReminders")} onChange={(v) => set("tgReminders", String(v))} label="Напоминать перед уроком" />
              <div className="mb-2 mt-1 max-w-48">
                <Field label="За сколько минут">
                  <Input type="number" min={1} max={1440} value={s.tgReminderMinutes} onChange={(e) => set("tgReminderMinutes", e.target.value)} />
                </Field>
              </div>
            </div>
            <div>
              <Toggle checked={bool("tgDigest")} onChange={(v) => set("tgDigest", String(v))} label="Утренняя сводка на день" />
              <div className="mb-2 mt-1 max-w-48">
                <Field label="Во сколько">
                  <Input type="time" value={s.tgDigestTime} onChange={(e) => set("tgDigestTime", e.target.value)} />
                </Field>
              </div>
            </div>
          </div>
          <Toggle checked={bool("tgReports")} onChange={(v) => set("tgReports", String(v))} label="Сообщать об изменениях расписания, найденных на сайте" />
          <p className="mt-2 text-xs text-muted">Уведомления приходят, пока приложение запущено (окно можно свернуть).</p>
        </Card>

        <Card id="auto" title="Автоматизация и общие настройки">
          <Toggle checked={bool("backgroundEnabled")} onChange={(v) => set("backgroundEnabled", String(v))} label="Фоновая работа" hint="Автопроверка сайтов, напоминания, повторные отправки в Google — пока приложение запущено." />
          <Toggle checked={bool("autoApplyChat")} onChange={(v) => set("autoApplyChat", String(v))} label="Применять правки из чата без подтверждения" hint="Только добавления и переносы. Отмены уроков всегда требуют подтверждения. Рекомендуем включать после проверки на тестовых данных." />
          <div className="mt-3 grid gap-4 sm:grid-cols-2">
            <Field label="Часовой пояс" hint="Все даты и время считаются в нём.">
              <div className="flex gap-2">
                <Input list="tz-list" value={s.timezone} onChange={(e) => set("timezone", e.target.value)} />
                <Button onClick={() => set("timezone", Intl.DateTimeFormat().resolvedOptions().timeZone)} title="Определить по компьютеру">
                  Авто
                </Button>
              </div>
              <datalist id="tz-list">
                {tzList.map((z) => (
                  <option key={z} value={z} />
                ))}
              </datalist>
            </Field>
            <Field label="Длительность урока по умолчанию (мин)" hint="Если время конца не указано.">
              <Input type="number" min={5} max={600} value={s.defaultDuration} onChange={(e) => set("defaultDuration", e.target.value)} />
            </Field>
            <Field label="Браузер для чтения сайтов" hint="Используется уже установленный у вас браузер.">
              <Select value={s.browserChannel} onChange={(e) => set("browserChannel", e.target.value)}>
                <option value="msedge">Microsoft Edge</option>
                <option value="chrome">Google Chrome</option>
                <option value="chromium">Встроенный Chromium</option>
              </Select>
            </Field>
          </div>
        </Card>

        <Card id="backup" title="Копия настроек" desc="Перенос на другой компьютер. Пароли, ключи и токены в файл НЕ попадают — их нужно вводить заново.">
          <div className="flex flex-wrap gap-2">
            <Button
              icon="download"
              onClick={() =>
                run("exp", async () => {
                  const data = await api("/api/export");
                  const url = URL.createObjectURL(new Blob([JSON.stringify(data, null, 2)], { type: "application/json" }));
                  const a = document.createElement("a");
                  a.href = url;
                  a.download = "raspisanie-settings.json";
                  a.click();
                  URL.revokeObjectURL(url);
                })
              }
            >
              Скачать настройки
            </Button>
            <Button icon="upload" onClick={() => fileRef.current?.click()}>
              Загрузить настройки
            </Button>
            <input
              ref={fileRef}
              type="file"
              accept="application/json"
              hidden
              onChange={(e) =>
                run("imp", async () => {
                  const f = e.target.files?.[0];
                  if (!f) return;
                  const r = await api<{ message: string }>("/api/export", { body: JSON.parse(await f.text()) });
                  toast(r.message, "ok");
                  await load();
                })
              }
            />
          </div>
        </Card>
      </div>

      <aside className="sticky top-6 hidden h-fit w-48 shrink-0 lg:block">
        <ul className="border-l border-line">
          {SECTIONS.map(([id, label]) => (
            <li key={id}>
              <a href={`#${id}`} className="-ml-px block border-l-2 border-transparent py-2 pl-4 text-sm text-muted hover:border-accent hover:text-fg">
                {label}
              </a>
            </li>
          ))}
        </ul>
      </aside>
    </div>
  );
}
