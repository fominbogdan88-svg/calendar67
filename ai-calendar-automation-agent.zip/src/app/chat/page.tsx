"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import PlanCard, { type PlanData } from "@/components/PlanCard";
import { Badge, Button, Icon, Spinner, Textarea, useToast } from "@/components/ui";
import { api } from "@/lib/client";

type Msg = {
  id: number;
  role: "user" | "assistant" | "tool";
  content: string;
  kind: string;
  images: string[];
  plan: PlanData | null;
};

const SUGGEST = [
  "Покажи расписание на эту неделю",
  "Добавь урок английского завтра в 15:00 на час",
  "Перенеси ближайшую математику на час позже",
  "Отмени урок в пятницу",
];

async function shrink(file: File): Promise<string> {
  const url = URL.createObjectURL(file);
  try {
    const img = await new Promise<HTMLImageElement>((res, rej) => {
      const i = new Image();
      i.onload = () => res(i);
      i.onerror = () => rej(new Error("Не удалось прочитать картинку"));
      i.src = url;
    });
    const max = 1600;
    const k = Math.min(1, max / Math.max(img.width, img.height));
    const c = document.createElement("canvas");
    c.width = Math.round(img.width * k);
    c.height = Math.round(img.height * k);
    const ctx = c.getContext("2d")!;
    ctx.fillStyle = "#fff";
    ctx.fillRect(0, 0, c.width, c.height);
    ctx.drawImage(img, 0, 0, c.width, c.height);
    return c.toDataURL("image/jpeg", 0.88);
  } finally {
    URL.revokeObjectURL(url);
  }
}

export default function ChatPage() {
  const toast = useToast();
  const [msgs, setMsgs] = useState<Msg[]>([]);
  const [model, setModel] = useState("");
  const [provider, setProvider] = useState("");
  const [text, setText] = useState("");
  const [images, setImages] = useState<string[]>([]);
  const [busy, setBusy] = useState(false);
  const [elapsed, setElapsed] = useState(0);
  const [drag, setDrag] = useState(false);
  const [answer, setAnswer] = useState("");
  const endRef = useRef<HTMLDivElement>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  const load = useCallback(async () => {
    try {
      const r = await api<{ messages: Msg[]; model: string; provider: string }>("/api/chat");
      setMsgs(r.messages);
      setModel(r.model);
      setProvider(r.provider);
    } catch (e) {
      toast((e as Error).message, "error");
    }
  }, [toast]);
  useEffect(() => {
    void load();
  }, [load]);
  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [msgs, busy]);
  useEffect(() => {
    if (!busy) return;
    setElapsed(0);
    const id = setInterval(() => setElapsed((x) => x + 1), 1000);
    return () => clearInterval(id);
  }, [busy]);

  async function addFiles(files: FileList | File[]) {
    const list = Array.from(files).filter((f) => f.type.startsWith("image/")).slice(0, 4 - images.length);
    if (!list.length) return;
    try {
      const urls = await Promise.all(list.map(shrink));
      setImages((x) => [...x, ...urls].slice(0, 4));
    } catch (e) {
      toast((e as Error).message, "error");
    }
  }

  async function send(override?: string) {
    const t = (override ?? text).trim();
    if (busy || (!t && !images.length)) return;
    setBusy(true);
    const imgs = images;
    setText("");
    setImages([]);
    setMsgs((m) => [...m, { id: -1, role: "user", content: t || "(картинка)", kind: "text", images: imgs, plan: null }]);
    try {
      await api("/api/chat", { body: { text: t, images: imgs } });
    } catch (e) {
      toast((e as Error).message, "error");
      setText(t);
      setImages(imgs);
    } finally {
      setBusy(false);
      await load();
    }
  }

  async function sendAnswer() {
    if (!answer.trim()) return;
    setBusy(true);
    try {
      await api("/api/chat", { body: { manualAnswer: answer } });
      setAnswer("");
    } catch (e) {
      toast((e as Error).message, "error");
    } finally {
      setBusy(false);
      await load();
    }
  }

  async function clear() {
    if (!confirm("Очистить историю чата? Расписание не изменится.")) return;
    await api("/api/chat", { method: "DELETE" });
    await load();
  }

  const last = msgs[msgs.length - 1];
  const waitingManual = provider === "manual" && last?.kind === "manual_prompt";

  return (
    <div
      className="relative mx-auto flex h-full max-w-4xl flex-col px-4 sm:px-8"
      onDragOver={(e) => {
        e.preventDefault();
        setDrag(true);
      }}
      onDragLeave={(e) => e.currentTarget === e.target && setDrag(false)}
      onDrop={(e) => {
        e.preventDefault();
        setDrag(false);
        void addFiles(e.dataTransfer.files);
      }}
    >
      <div className="flex items-center justify-between gap-3 py-5">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Чат с агентом</h1>
          <p className="mt-1 flex flex-wrap items-center gap-2 text-sm text-muted">
            Модель: <Badge tone="accent">{model || "…"}</Badge> Любое изменение — только после вашего подтверждения.
          </p>
        </div>
        <Button size="sm" variant="ghost" icon="trash" onClick={clear}>
          Очистить
        </Button>
      </div>

      {drag && (
        <div className="pointer-events-none absolute inset-4 z-30 flex items-center justify-center rounded-xl border-2 border-dashed border-accent bg-bg/90 text-lg font-semibold">
          Отпустите картинку расписания здесь
        </div>
      )}

      <div className="min-h-0 flex-1 space-y-4 overflow-y-auto pb-4">
        {msgs.length === 0 && (
          <div className="rounded-lg border border-line bg-panel p-6">
            <div className="mb-1 text-lg font-semibold">Чем помочь?</div>
            <p className="mb-4 text-sm text-muted">
              Напишите, что изменить в расписании, или перетащите сюда скриншот расписания — агент прочитает его и предложит план. Новичок? Откройте раздел «Инструкция».
            </p>
            <div className="flex flex-wrap gap-2">
              {SUGGEST.map((s) => (
                <button key={s} onClick={() => setText(s)} className="cursor-pointer rounded-full border border-line px-3 py-1.5 text-sm text-muted hover:bg-panel2 hover:text-fg">
                  {s}
                </button>
              ))}
            </div>
          </div>
        )}

        {msgs.map((m, i) => {
          if (m.kind === "manual_prompt") {
            return (
              <div key={m.id} className="rounded-lg border border-line bg-panel p-4">
                <div className="mb-1 text-sm font-semibold">Шаг 1. Скопируйте запрос и вставьте его в веб-чат (ChatGPT, Claude, Gemini…)</div>
                <p className="mb-2 text-xs text-muted">Если у вас картинка расписания — приложите её в веб-чате вместе с этим текстом.</p>
                <Textarea readOnly rows={5} value={m.content} className="font-mono text-xs" />
                <div className="mt-2 flex flex-wrap gap-2">
                  <Button
                    size="sm"
                    variant="primary"
                    icon="copy"
                    onClick={() => {
                      void navigator.clipboard.writeText(m.content).then(() => toast("Скопировано", "ok"));
                    }}
                  >
                    Копировать запрос
                  </Button>
                  {[
                    ["ChatGPT", "https://chatgpt.com"],
                    ["Claude", "https://claude.ai"],
                    ["Gemini", "https://gemini.google.com"],
                  ].map(([n, u]) => (
                    <a key={n} href={u} target="_blank" rel="noreferrer" className="inline-flex h-8 items-center rounded-md border border-line px-3 text-xs hover:bg-panel2">
                      Открыть {n}
                    </a>
                  ))}
                </div>
                {i === msgs.length - 1 && (
                  <div className="mt-4 border-t border-line pt-4">
                    <div className="mb-1 text-sm font-semibold">Шаг 2. Вставьте сюда ответ веб-ассистента (JSON)</div>
                    <Textarea rows={4} value={answer} onChange={(e) => setAnswer(e.target.value)} placeholder='{"reply": "...", "operations": [...]}' className="font-mono text-xs" />
                    <Button className="mt-2" variant="primary" icon="send" loading={busy} onClick={sendAnswer} disabled={!answer.trim()}>
                      Передать ответ агенту
                    </Button>
                  </div>
                )}
              </div>
            );
          }
          if (m.role === "tool") {
            return (
              <div key={m.id} className="mx-auto max-w-xl rounded-md border border-line px-3 py-2 text-center text-xs text-muted">
                {m.content}
              </div>
            );
          }
          const mine = m.role === "user";
          return (
            <div key={m.id} className={`flex ${mine ? "justify-end" : "justify-start"}`}>
              <div className={`max-w-[88%] rounded-lg border px-4 py-3 text-sm ${mine ? "border-accent/40 bg-accent/10" : "border-line bg-panel"}`}>
                {m.images?.length > 0 && (
                  <div className="mb-2 flex flex-wrap gap-2">
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    {m.images.map((src, k) => <img key={k} src={src} alt="Приложенная картинка" className="max-h-40 rounded-md border border-line" />)}
                  </div>
                )}
                <div className="whitespace-pre-wrap leading-relaxed">{m.content}</div>
                {m.plan && <PlanCard plan={m.plan} onDone={load} />}
              </div>
            </div>
          );
        })}

        {busy && (
          <div className="flex items-center gap-2 text-sm text-muted">
            <Spinner /> Агент работает… {elapsed} с{provider === "ollama" && elapsed > 20 ? " (локальная модель может думать до минуты)" : ""}
          </div>
        )}
        <div ref={endRef} />
      </div>

      {!waitingManual && (
        <div className="sticky bottom-0 bg-bg pb-5 pt-2">
          {images.length > 0 && (
            <div className="mb-2 flex gap-2">
              {images.map((src, k) => (
                <div key={k} className="relative">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img src={src} alt="Превью" className="h-16 rounded-md border border-line" />
                  <button
                    onClick={() => setImages(images.filter((_, j) => j !== k))}
                    className="absolute -right-1.5 -top-1.5 flex h-5 w-5 cursor-pointer items-center justify-center rounded-full bg-danger text-white"
                    aria-label="Убрать"
                  >
                    <Icon name="x" size={12} />
                  </button>
                </div>
              ))}
            </div>
          )}
          <div className="flex items-end gap-2 rounded-lg border border-line bg-panel p-2 focus-within:border-accent">
            <input ref={fileRef} type="file" accept="image/*" multiple hidden onChange={(e) => e.target.files && addFiles(e.target.files)} />
            <Button variant="ghost" onClick={() => fileRef.current?.click()} aria-label="Прикрепить картинку" title="Прикрепить картинку расписания">
              <Icon name="image" />
            </Button>
            <textarea
              value={text}
              rows={1}
              onChange={(e) => setText(e.target.value)}
              onPaste={(e) => {
                const f = Array.from(e.clipboardData.files);
                if (f.length) {
                  e.preventDefault();
                  void addFiles(f);
                }
              }}
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault();
                  void send();
                }
              }}
              placeholder="Напишите запрос… (Enter — отправить, Shift+Enter — новая строка)"
              className="max-h-40 min-h-10 flex-1 resize-none bg-transparent px-2 py-2 text-sm outline-none placeholder:text-muted/70"
            />
            <Button variant="primary" icon="send" loading={busy} onClick={() => send()} disabled={!text.trim() && !images.length}>
              Отправить
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}
