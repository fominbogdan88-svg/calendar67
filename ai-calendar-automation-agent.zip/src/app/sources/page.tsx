"use client";

import Link from "next/link";
import { useCallback, useEffect, useState } from "react";
import PendingPlans from "@/components/PendingPlans";
import { Badge, Button, Card, Field, Icon, Input, Modal, Select, Toggle, useToast } from "@/components/ui";
import { api } from "@/lib/client";

type Source = {
  id: number;
  name: string;
  url: string;
  selector: string;
  enabled: boolean;
  intervalMinutes: number;
  autoApply: boolean;
  lastRunAt: string | null;
  lastStatus: string;
  lastMessage: string;
  lastCount: number;
};

const STATUS: Record<string, { label: string; tone: "muted" | "ok" | "warn" | "danger" }> = {
  never: { label: "ещё не читали", tone: "muted" },
  ok: { label: "всё актуально", tone: "ok" },
  unchanged: { label: "без изменений", tone: "ok" },
  pending: { label: "ждёт подтверждения", tone: "warn" },
  login_required: { label: "нужен вход", tone: "warn" },
  blocked: { label: "сайт заблокировал", tone: "warn" },
  empty: { label: "уроки не найдены", tone: "warn" },
  error: { label: "ошибка", tone: "danger" },
};

const INTERVALS = [
  [0, "Только вручную"],
  [30, "Каждые 30 минут"],
  [60, "Каждый час"],
  [180, "Каждые 3 часа"],
  [720, "Два раза в день"],
  [1440, "Раз в сутки"],
];

type Form = { id?: number; name: string; url: string; selector: string; intervalMinutes: number; autoApply: boolean };
const EMPTY: Form = { name: "", url: "", selector: "", intervalMinutes: 60, autoApply: false };

export default function SourcesPage() {
  const toast = useToast();
  const [list, setList] = useState<Source[]>([]);
  const [form, setForm] = useState<Form | null>(null);
  const [saving, setSaving] = useState(false);
  const [busy, setBusy] = useState<string | null>(null);

  const load = useCallback(async () => {
    try {
      setList((await api<{ sources: Source[] }>("/api/sources")).sources);
    } catch (e) {
      toast((e as Error).message, "error");
    }
  }, [toast]);
  useEffect(() => {
    void load();
  }, [load]);

  async function save() {
    if (!form) return;
    setSaving(true);
    try {
      if (form.id) await api(`/api/sources/${form.id}`, { method: "PATCH", body: form });
      else await api("/api/sources", { body: form });
      setForm(null);
      await load();
      toast("Сохранено", "ok");
    } catch (e) {
      toast((e as Error).message, "error");
    } finally {
      setSaving(false);
    }
  }

  async function patch(id: number, body: Record<string, unknown>) {
    try {
      await api(`/api/sources/${id}`, { method: "PATCH", body });
      await load();
    } catch (e) {
      toast((e as Error).message, "error");
    }
  }

  async function run(s: Source) {
    setBusy(`run${s.id}`);
    toast("Читаю сайт… Это может занять до пары минут.", "info");
    try {
      const r = await api<{ status: string; message: string }>(`/api/sources/${s.id}/run`, { method: "POST", body: {} });
      toast(r.message, r.status === "error" ? "error" : "ok");
    } catch (e) {
      toast((e as Error).message, "error");
    } finally {
      setBusy(null);
      await load();
    }
  }

  async function login(s: Source) {
    setBusy(`login${s.id}`);
    try {
      const r = await api<{ message: string }>(`/api/sources/${s.id}/login`, { method: "POST", body: {} });
      toast(r.message, "ok");
    } catch (e) {
      toast((e as Error).message, "error");
    } finally {
      setBusy(null);
    }
  }

  async function remove(s: Source) {
    if (!confirm(`Удалить источник «${s.name}»? Уже добавленные уроки останутся в календаре.`)) return;
    await api(`/api/sources/${s.id}`, { method: "DELETE" });
    await load();
  }

  return (
    <div className="mx-auto max-w-4xl space-y-6 px-4 py-6 sm:px-8">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Источники (сайты школ)</h1>
          <p className="mt-1 text-sm text-muted">Агент сам открывает сайт школы в браузере, находит уроки и приводит календарь в соответствие.</p>
        </div>
        <Button variant="primary" icon="plus" onClick={() => setForm(EMPTY)}>
          Добавить сайт
        </Button>
      </div>

      <PendingPlans onChange={load} />

      {list.length === 0 && (
        <Card title="Пока нет ни одного сайта">
          <p className="text-sm text-muted leading-relaxed">
            Нажмите «Добавить сайт» и вставьте ссылку на страницу с расписанием. Если сайт требует вход — нажмите «Войти в браузере» и авторизуйтесь один раз: пароль приложению не нужен.
            Подробности — в <Link href="/guide#school" className="text-link underline">инструкции</Link>.
          </p>
        </Card>
      )}

      {list.map((s) => {
        const st = STATUS[s.lastStatus] ?? STATUS.never;
        return (
          <Card key={s.id}>
            <div className="flex flex-wrap items-start justify-between gap-3">
              <div className="min-w-0">
                <div className="flex flex-wrap items-center gap-2">
                  <h2 className="text-lg font-semibold">{s.name}</h2>
                  <Badge tone={st.tone}>{st.label}</Badge>
                  {!s.enabled && <Badge>выключен</Badge>}
                </div>
                <a href={s.url} target="_blank" rel="noreferrer" className="mt-1 block max-w-full truncate text-sm text-link underline">
                  {s.url}
                </a>
                {s.selector && <div className="mt-1 text-xs text-muted">Блок на странице: {s.selector}</div>}
              </div>
              <div className="flex flex-wrap gap-2">
                <Button size="sm" variant="primary" icon="play" loading={busy === `run${s.id}`} onClick={() => run(s)}>
                  Прочитать сейчас
                </Button>
                <Button size="sm" icon="globe" loading={busy === `login${s.id}`} onClick={() => login(s)}>
                  Войти в браузере
                </Button>
                <Button size="sm" variant="ghost" icon="edit" onClick={() => setForm({ id: s.id, name: s.name, url: s.url, selector: s.selector, intervalMinutes: s.intervalMinutes, autoApply: s.autoApply })} aria-label="Изменить" />
                <Button size="sm" variant="ghost" icon="trash" onClick={() => remove(s)} aria-label="Удалить" />
              </div>
            </div>
            {s.lastMessage && <p className="mt-3 rounded-md border border-line bg-bg p-3 text-sm text-muted leading-relaxed">{s.lastMessage}</p>}
            <div className="mt-3 text-xs text-muted">
              Последняя проверка: {s.lastRunAt ? new Date(s.lastRunAt).toLocaleString("ru-RU") : "—"} · найдено уроков: {s.lastCount}
            </div>
            <div className="mt-3 grid gap-x-8 sm:grid-cols-2">
              <Toggle checked={s.enabled} onChange={(v) => patch(s.id, { enabled: v })} label="Проверять автоматически" hint="Пока приложение запущено" />
              <Toggle checked={s.autoApply} onChange={(v) => patch(s.id, { autoApply: v })} label="Применять новые и перенесённые уроки сразу" hint="Отмены всегда ждут вашего подтверждения" />
            </div>
          </Card>
        );
      })}

      <Card title="Как это работает и почему безопасно">
        <ul className="space-y-2 text-sm text-muted leading-relaxed">
          <li className="flex gap-2"><Icon name="check" size={16} className="mt-0.5 text-link" />Сайт открывается настоящим браузером (Edge/Chrome), поэтому работают и «умные» сайты на JavaScript.</li>
          <li className="flex gap-2"><Icon name="check" size={16} className="mt-0.5 text-link" />Текст страницы считается недоверенным: ИИ только вытаскивает из него уроки, а все даты и время проверяет программа.</li>
          <li className="flex gap-2"><Icon name="check" size={16} className="mt-0.5 text-link" />Если страница пустая или уроков подозрительно мало — ничего не удаляется. Отмена урока — только с вашего подтверждения.</li>
          <li className="flex gap-2"><Icon name="check" size={16} className="mt-0.5 text-link" />Повторное чтение не создаёт дублей: перенесённый урок обновляется, а не добавляется заново.</li>
        </ul>
      </Card>

      <Modal open={!!form} onClose={() => setForm(null)} title={form?.id ? "Изменить источник" : "Новый источник"}>
        {form && (
          <div className="space-y-3">
            <Field label="Название">
              <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Моя онлайн-школа" autoFocus />
            </Field>
            <Field label="Ссылка на страницу с расписанием" hint="Лучше ссылка именно на раздел «Расписание», а не на главную.">
              <Input value={form.url} onChange={(e) => setForm({ ...form, url: e.target.value })} placeholder="https://school.example.com/schedule" />
            </Field>
            <Field label="Блок расписания (CSS-селектор) — необязательно" hint="Нужен только если страница очень длинная. Пример: .schedule или #lessons. Оставьте пустым — прочитается вся страница.">
              <Input value={form.selector} onChange={(e) => setForm({ ...form, selector: e.target.value })} />
            </Field>
            <Field label="Как часто проверять">
              <Select value={form.intervalMinutes} onChange={(e) => setForm({ ...form, intervalMinutes: Number(e.target.value) })}>
                {INTERVALS.map(([v, l]) => (
                  <option key={v} value={v}>
                    {l}
                  </option>
                ))}
              </Select>
            </Field>
            <Toggle checked={form.autoApply} onChange={(v) => setForm({ ...form, autoApply: v })} label="Применять новые и перенесённые уроки без подтверждения" hint="Рекомендуем включать после того, как вы проверили работу на тестовом чтении." />
            <div className="flex justify-end gap-2 pt-2">
              <Button variant="ghost" onClick={() => setForm(null)}>
                Отмена
              </Button>
              <Button variant="primary" loading={saving} onClick={save}>
                Сохранить
              </Button>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
}
